import Foundation

class ClothesBuilder {
    static func build(clothes: Clothes) -> ClothesViewController {
        
        let vc = ClothesViewController(clothes: clothes)
        let router = ClothesRouter(view: vc)
        let presenter = ClothesPresenter(view: vc, router: router)
        
        vc.presenter = presenter
        
        return vc
    }
}
