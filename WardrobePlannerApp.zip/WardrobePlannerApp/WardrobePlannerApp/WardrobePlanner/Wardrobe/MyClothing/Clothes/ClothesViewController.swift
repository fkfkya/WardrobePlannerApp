import UIKit

final class ClothesViewController: UIViewController, UITextFieldDelegate, UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    
    // MARK: - Fields
    var presenter: ClothesPresenter!
    
    private var clothes: Clothes
    
    private let nameField: UITextField = UITextField()
    private let descriptionField: UITextField = UITextField()
    
    private let categoryLabel: UILabel = UILabel()
    private let costLabel: UILabel = UILabel()
    private let sizeLabel: UILabel = UILabel()
    
    private let deleteButton: UIButton = UIButton(type: .system)
    private let wishButton: UIButton = UIButton(type: .system)
    private let addPhotoButton: UIButton = UIButton(type: .system)
    private let saveButton: UIButton = UIButton(type: .system)
    
    private let itemImage = UIImageView()
    
    private var picture = AddingClothesConstans.Images.thing
    
    init(clothes: Clothes) {
        self.clothes = clothes
        super.init(nibName: nil, bundle: nil)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    // MARK: - Lifecycle
    override func viewDidLoad() {
        super.viewDidLoad()
        self.hideKeyboardWhenTappedAround()
        
        configureUI()
    }
    
    
    // MARK: - Actions
    @objc
    private func backButtonTapped() {
        presenter?.backButtonTapped()
    }
    
    @objc func wishButtonTapped() {
        if wishButton.currentImage == UIImage(systemName: "heart") {
            wishButton.setImage(UIImage(systemName: "heart.fill"), for: .normal)
            clothes.wish = true
        } else {
            wishButton.setImage(UIImage(systemName: "heart"), for: .normal)
            clothes.wish = false
        }
        ClothesDataManager.shared.setWish(clothes: clothes)
    }
    
    @objc
    private func addPhotoButtonTapped() {
        let imagePicker = UIImagePickerController()
        imagePicker.delegate = self
        imagePicker.allowsEditing = true
        imagePicker.sourceType = .photoLibrary
        
        present(imagePicker, animated: true, completion: nil)
    }
    
    @objc 
    func deleteButtonTapped() {
        presenter?.deleteClothes(clothesToDelte: clothes)
    }
    
    @objc
    private func saveButtonTapped() {

        if let name = nameField.text, !name.isEmpty {
            let description = ((descriptionField.text?.isEmpty) != nil) ? "" : descriptionField.text
            let photo = itemImage.image
            let category = "SS23"
        
            clothes.image = photo
            clothes.name = name
            clothes.description = description
            clothes.category = category
          
            presenter.editClothes(clothesToSave: clothes)
            return
        }
        
    }
    
    func showAlert(message: String) {
        let alertController = UIAlertController(title: "Error", message: message, preferredStyle: .alert)
        let okAction = UIAlertAction(title: "OK", style: .default, handler: nil)
        alertController.addAction(okAction)
        present(alertController, animated: true, completion: nil)
    }
    

    func showGoodAlert(message: String, completion: (() -> Void)? = nil) {
        let alertController = UIAlertController(title: "Success!", message: message, preferredStyle: .alert)
        let okAction = UIAlertAction(title: "OK", style: .default) { _ in
            completion?()
        }
        alertController.addAction(okAction)
        present(alertController, animated: true, completion: nil)
    }
    
    func showDeleteAlert(message: String, completion: (() -> Void)? = nil) {
        let alertController = UIAlertController(title: "Deleting", message: message, preferredStyle: .alert)
        let okAction = UIAlertAction(title: "OK", style: .default) { _ in
            completion?()
        }
        let cancelAction = UIAlertAction(title: "Cancel", style: .default) {_ in 
            return
        }
        alertController.addAction(okAction)
        alertController.addAction(cancelAction)
        present(alertController, animated: true, completion: nil)
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
            if let selectedImage = info[.editedImage] as? UIImage {
                itemImage.image = selectedImage
            }
        picker.dismiss(animated: true, completion: nil)
    }
    
}



// MARK: - Configurations
extension ClothesViewController {
    
    private func configureUI() {
        view.backgroundColor = ColorsConstants.background
    
        configureItemImage()
        configureNameField()
        configureSizeAndCostLabels()
        configureDescriptionField()
        configureCategoryLabel()
        configureButtons()
    }
    
    // MARK: - Text Fields
    private func configureNameField() {
        view.addSubview(nameField)
        nameField.translatesAutoresizingMaskIntoConstraints = false
        
        nameField.delegate = self
        
        nameField.backgroundColor = .systemGray6
        nameField.placeholder = clothes.name
        nameField.font = UIFont.systemFont(ofSize: 18, weight: .bold)
        nameField.layer.cornerRadius = 15
        nameField.returnKeyType = .done
        
        nameField.autocapitalizationType = .none
        nameField.autocorrectionType = .no
        
        nameField.leftView = UIView(frame: CGRect(x: .zero, y: .zero, width: 20, height: 50))
        nameField.rightView = UIView(frame: CGRect(x: .zero, y: .zero, width: 20, height: 50))
        nameField.leftViewMode = .always
        nameField.rightViewMode = .always
        
        nameField.setWidth(350)
        nameField.setHeight(35)
        nameField.pinTop(to: itemImage.bottomAnchor, 20)
        nameField.pinCenterX(to: view.centerXAnchor)
    }
    
    private func configureDescriptionField() {
        view.addSubview(descriptionField)
        descriptionField.translatesAutoresizingMaskIntoConstraints = false
        
        descriptionField.delegate = self
        
        descriptionField.backgroundColor = .systemGray6
        descriptionField.placeholder = clothes.description
        descriptionField.font = UIFont.systemFont(ofSize: 18, weight: .bold)
        descriptionField.layer.cornerRadius = 15
        descriptionField.returnKeyType = .done
        
        descriptionField.autocapitalizationType = .none
        descriptionField.autocorrectionType = .no
        
        descriptionField.leftView = UIView(frame: CGRect(x: .zero, y: .zero, width: 20, height: 50))
        descriptionField.rightView = UIView(frame: CGRect(x: .zero, y: .zero, width: 20, height: 50))
        descriptionField.leftViewMode = .always
        descriptionField.rightViewMode = .always
        
        descriptionField.setWidth(350)
        descriptionField.setHeight(100)
        descriptionField.pinTop(to: sizeLabel.bottomAnchor, 20)
        descriptionField.pinCenterX(to: view.centerXAnchor)
    }
    
    // MARK: - Labels
    private func configureSizeAndCostLabels() {
        view.addSubview(sizeLabel)
        sizeLabel.translatesAutoresizingMaskIntoConstraints = false
        
        sizeLabel.text = "Size: \(clothes.size)"
        sizeLabel.font = UIFont.systemFont(ofSize: ProfileConstants.Sizes.photoLabel, weight: .bold)
        
        sizeLabel.pinTop(to: nameField.bottomAnchor, 20)
        sizeLabel.pinLeft(to: nameField.leadingAnchor, 5)
        
        view.addSubview(costLabel)
        costLabel.translatesAutoresizingMaskIntoConstraints = false
        
        costLabel.text = "Cost: \(clothes.cost)$"
        costLabel.font = UIFont.systemFont(ofSize: ProfileConstants.Sizes.photoLabel, weight: .bold)
        
        costLabel.pinTop(to: nameField.bottomAnchor, 20)
        costLabel.pinRight(to: nameField.trailingAnchor, 5)
    }
    
    private func configureCategoryLabel() {
        view.addSubview(categoryLabel)
        categoryLabel.translatesAutoresizingMaskIntoConstraints = false
        
        categoryLabel.text = "Category: \(clothes.category ?? "")"
        categoryLabel.font = UIFont.systemFont(ofSize: ProfileConstants.Sizes.photoLabel, weight: .heavy)
        
        categoryLabel.pinTop(to: descriptionField.bottomAnchor, 20)
        categoryLabel.pinLeft(to: descriptionField.leadingAnchor, 16)
    }
    
    // MARK: - Buttons
    private func configureButtons() {
        configureBackButton()
        configureAddPhotoButton()
        configureSaveButton()
        configureWishButton()
        configureDeleteButton()
    }
    
    private func configureDeleteButton() {
        view.addSubview(deleteButton)
        deleteButton.translatesAutoresizingMaskIntoConstraints = false
            
        deleteButton.setImage(UIImage(systemName: "multiply"), for: .normal)
        deleteButton.tintColor = .red
        
        deleteButton.addTarget(self, action: #selector(deleteButtonTapped), for: .touchUpInside)
        
        deleteButton.pinBottom(to: itemImage.bottomAnchor, 5)
        deleteButton.pinRight(to: itemImage.leadingAnchor,10)
    }
    
    private func configureWishButton() {
        view.addSubview(wishButton)
        wishButton.translatesAutoresizingMaskIntoConstraints = false
        let icon = clothes.wish ? "heart.fill" : "heart"
        wishButton.setImage(UIImage(systemName: icon), for: .normal)
        wishButton.tintColor = .red
        
        wishButton.addTarget(self, action: #selector(wishButtonTapped), for: .touchUpInside)
        
        wishButton.pinBottom(to: itemImage.bottomAnchor, 5)
        wishButton.pinLeft(to: itemImage.trailingAnchor,10)
    }
    
    private func configureBackButton() {
        let largeFont = UIFont.systemFont(ofSize: 20, weight: .bold)
        let configuration = UIImage.SymbolConfiguration(font: largeFont)
        let image = UIImage(systemName: "chevron.left", withConfiguration: configuration)
        navigationItem.leftBarButtonItem = UIBarButtonItem(image: image, style: .plain, target: self, action: #selector(backButtonTapped))
        navigationItem.leftBarButtonItem?.tintColor = .black
    }
    
    private func configureAddPhotoButton() {
        let largeFont = UIFont.systemFont(ofSize: 20, weight: .bold)
        let configuration = UIImage.SymbolConfiguration(font: largeFont)
        let image = UIImage(systemName: "camera", withConfiguration: configuration)
        navigationItem.rightBarButtonItem = UIBarButtonItem(image: image, style: .plain, target: self, action: #selector(addPhotoButtonTapped))
        navigationItem.rightBarButtonItem?.tintColor = .black
    }
    
    private func configureSaveButton() {
        view.addSubview(saveButton)
        saveButton.translatesAutoresizingMaskIntoConstraints = false
        
        saveButton.setTitle("Save", for: .normal)
        saveButton.setTitleColor(UIColor(named: "customPurple"), for: .normal)
        saveButton.titleLabel?.font = UIFont.systemFont(ofSize: 20, weight: .bold)
        saveButton.layer.borderColor = UIColor(named: "customPurple")?.cgColor
        saveButton.layer.borderWidth = AuthConstants.registerBorderWidth
        saveButton.layer.cornerRadius = 17
        
        saveButton.addTarget(self, action: #selector(saveButtonTapped), for: .touchUpInside)
        
        saveButton.pinBottom(to: view.safeAreaLayoutGuide.bottomAnchor, 50)
        saveButton.pinCenterX(to: view.centerXAnchor)
        saveButton.setHeight(35)
        saveButton.setWidth(175)
    }
 
    // MARK: - Images
    private func configureItemImage() {
        itemImage.image = clothes.image
        view.addSubview(itemImage)
        itemImage.translatesAutoresizingMaskIntoConstraints = false
        
        itemImage.layer.cornerRadius = 20
        itemImage.clipsToBounds = true
        
        itemImage.pinTop(to: view.safeAreaLayoutGuide.topAnchor, -30)
        itemImage.pinCenterX(to: view.centerXAnchor)
        itemImage.setHeight(260)
        itemImage.setWidth(260)
    }
    
}
