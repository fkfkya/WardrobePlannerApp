import UIKit

final class ClothesRouter {
    
    private weak var view: UIViewController?
    
    init(view: UIViewController) {
        self.view = view
    }
    
    func navigateToWardrobe() {
        view?.navigationController?.popViewController(animated: true)
    }
}

