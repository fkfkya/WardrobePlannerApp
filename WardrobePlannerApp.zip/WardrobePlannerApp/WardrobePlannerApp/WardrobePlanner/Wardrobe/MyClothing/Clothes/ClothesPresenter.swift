import Foundation

final class ClothesPresenter {
    private weak var view: ClothesViewController?
    private var router: ClothesRouter
    
    init(view: ClothesViewController?, router: ClothesRouter) {
        self.view = view
        self.router = router
    }
    
    func backButtonTapped() {
        router.navigateToWardrobe()
    }
    
    func editClothes(clothesToSave: Clothes) {
        ClothesDataManager.shared.addClothes(clothes: clothesToSave)
        view?.showGoodAlert(message: "Clothes has been edited succesfully!"){

            self.backButtonTapped()
        }
    }
    
    func deleteClothes(clothesToDelte: Clothes) {
        view?.showDeleteAlert(message: "Are you sure?") {
            ClothesDataManager.shared.deleteClothes(clothes: clothesToDelte)

            self.backButtonTapped()
            
        }
    }
}

