import UIKit

final class MyClothingRouter {
    
    private weak var view: UIViewController?
    
    init(view: UIViewController) {
        self.view = view
    }
    
    func navigateToWardrobe() {
        view?.navigationController?.popViewController(animated: true)
    }
    
    func navigateToCreateClothes() {
        let vc = CreateClothesBuilder.build()
        
        view?.navigationController?.pushViewController(vc, animated: true)
    }

    func navigateToItemScreen(clothes: Clothes) {
        let vc = ClothesBuilder.build(clothes: clothes)
        view?.navigationController?.pushViewController(vc, animated: true)
    }
}

