import UIKit
import Firebase
import FirebaseStorage

final class MyClothingViewController: UIViewController, UITextFieldDelegate{
    
    var presenter: MyClothingPresenter!
    
    // MARK: - Fields
    private let label: UILabel = UILabel()
    
    private var sum: Double = 0.0
    
    private let addButton: UIButton = UIButton()
    
    private let refreshControl = UIRefreshControl()
    
    private let collectionView: UICollectionView = UICollectionView(frame: .zero, collectionViewLayout: UICollectionViewFlowLayout())
    
    var clothesArray: [Clothes] = []

    
    // MARK: - LifeCycle
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationItem.hidesBackButton = true
        view.backgroundColor = ColorsConstants.background
        
        configureUI()
    }
    
    
    @objc 
    private func refreshCollectionView() {
        configureCollection { Bool in
            if Bool == true {
                self.addClothesToCollectionView()
                self.view.addSubview(self.collectionView)
                self.collectionView.pinHorizontal(to: self.view, 10)
                self.collectionView.pinBottom(to: self.view.safeAreaLayoutGuide.bottomAnchor)
                self.collectionView.pinTop(to: self.label.bottomAnchor, 15)
            }
        }
        refreshControl.endRefreshing()
    }
    
    @objc
    private func backButtonTapped() {
        presenter?.backButtonTapped()
    }
    
    @objc
    private func addTapped() {
        presenter?.addButtonTapped()
    }

}


extension MyClothingViewController {
    
    // MARK: - Configuration
    private func configureUI() {
        configureBackButton()
        configureLabel()
        configureAddButton()
        configureCollection { Bool in
            if Bool == true {
                self.addClothesToCollectionView()
                self.view.addSubview(self.collectionView)
                self.collectionView.pinHorizontal(to: self.view, 10)
                self.collectionView.pinBottom(to: self.view.safeAreaLayoutGuide.bottomAnchor)
                self.collectionView.pinTop(to: self.label.bottomAnchor, 15)
            }
        }
    }
    
    // MARK: - Buttons
    
    private func configureBackButton() {
        let largeFont = UIFont.systemFont(ofSize: 20, weight: .bold)
        let configuration = UIImage.SymbolConfiguration(font: largeFont)
        let image = UIImage(systemName: "chevron.left", withConfiguration: configuration)
        navigationItem.leftBarButtonItem = UIBarButtonItem(image: image, style: .plain, target: self, action: #selector(backButtonTapped))
        navigationItem.leftBarButtonItem?.tintColor = .black
    }
    
    private func configureAddButton() {
        
        let largeFont = UIFont.systemFont(ofSize: 20, weight: .bold)
        let configuration = UIImage.SymbolConfiguration(font: largeFont)
        let image = UIImage(systemName: "plus", withConfiguration: configuration)
        navigationItem.rightBarButtonItem = UIBarButtonItem(image: image, style: .plain, target: self, action: #selector(addTapped))
        navigationItem.rightBarButtonItem?.tintColor = .black
    }
    
    private func configureLabel() {
        view.addSubview(label)
        label.translatesAutoresizingMaskIntoConstraints = false
        
        label.text = "My clothes"
        label.font = UIFont.systemFont(ofSize: ProfileConstants.Sizes.photoLabel, weight: .heavy)
        
        label.pinTop(to: view.safeAreaLayoutGuide.topAnchor, -40)
        label.pinCenterX(to: view.centerXAnchor)
    }
    
    // MARK: - Collection
    func configureCollection(completion: @escaping (Bool) -> Void) {
        refreshControl.addTarget(self, action: #selector(refreshCollectionView), for: .valueChanged)
        collectionView.addSubview(refreshControl)
        collectionView.alwaysBounceVertical = true
        
        collectionView.reloadData()
        let currId = (Auth.auth().currentUser?.uid)!
        let collectionns = Firestore.firestore().collection("user").document(currId).collection("clothes")
        collectionns.order(by: "date", descending: true).getDocuments {(querySnapshot, error) in
            if let error = error {
                print("Ошибка получения документов: \(error.localizedDescription)")
                completion(false)
            } else {
                var clothesModel: [Clothes] = []
                let dispatchGroup = DispatchGroup()
                
                for document in querySnapshot!.documents {
                    let data = document.data()
                    if !data.isEmpty {
                        let name = data["name"] as! String
                        let date = data["date"] as! String
                        let cost = data["cost"] as! Double
                        let color = data["color"] as! String
                        let category = data["category"] as! String
                        let size = data["size"] as! String
                        let description = data["description"] as! String
                        let wish = data["wish"] as! Bool
                         
                        let storageRef = Storage.storage().reference().child("users_pictures/\(currId)/clothes/\(data["date"] as! String).jpg")
                        
                        
                        dispatchGroup.enter()
                        storageRef.getData(maxSize: 10 * 1024 * 1024) { dataImage, error in
                            defer {
                                dispatchGroup.leave()
                            }
                            if let error = error {
                                print("Ошибка загрузки фотографии из Firebase Storage: \(error.localizedDescription)")
                            } else {
                                if let imageData = dataImage, let image = UIImage(data: imageData) {
                                    let item = Clothes(color: UIColor(hexString: color), size: size, category: category, name: name, cost: cost, description: description, image: image, date: date, wish: wish)
                                    self.sum += item.cost
                                    clothesModel.append(item)
                                } else {
                                    print("Не удалось преобразовать данные в изображение")
                                }
                            }
                        }
                    }
                }
                dispatchGroup.notify(queue: .main) {
                    print("Все фотографии успешно загружены")
                    self.clothesArray = clothesModel.sorted { (firstItem: Clothes, secondItem: Clothes) -> Bool in
                        return firstItem.date! > secondItem.date!
                    }
                    UserDefaults.standard.set(String(self.sum), forKey: "total")
                    UserDefaults.standard.set(String(self.clothesArray.count), forKey: "numberOfItems")
                    print("number - \(self.clothesArray.count) cost - \(self.sum)")
                    completion(true)
                }
            }
        }
    }

    private func addClothesToCollectionView() {
    
        collectionView.delegate = self
        collectionView.dataSource = self
        collectionView.alwaysBounceVertical = true
        collectionView.showsVerticalScrollIndicator = false
        collectionView.backgroundColor = ColorsConstants.background
        
        if let layout = collectionView.collectionViewLayout as? UICollectionViewFlowLayout {
            layout.minimumInteritemSpacing = 5
            layout.minimumLineSpacing = 5
            layout.invalidateLayout()
        }
        
        collectionView.register(ClothesCell.self, forCellWithReuseIdentifier: "clothes")
    }

}

extension MyClothingViewController: UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return clothesArray.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: ClothesCell.reuseId, for: indexPath)
        
        guard let clothesCell = cell as? ClothesCell else {
            return cell
        }
        
        let clothes = clothesArray[indexPath.row]
        clothesCell.configure(with: clothes)
        
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: UIScreen.main.bounds.width / 2.2, height: 200)
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let clothes = clothesArray[indexPath.item]
        presenter.showItem(clothes: clothes)
        print("Cell tapped at index \(indexPath.item)")
    }
}
