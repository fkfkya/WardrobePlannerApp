import Foundation

class MyClothingBuilder {
    static func build() -> MyClothingViewController {
        
        let vc = MyClothingViewController()
        let router = MyClothingRouter(view: vc)
        let presenter = MyClothingPresenter(view: vc, router: router)
        
        vc.presenter = presenter
        
        return vc
    }
}
