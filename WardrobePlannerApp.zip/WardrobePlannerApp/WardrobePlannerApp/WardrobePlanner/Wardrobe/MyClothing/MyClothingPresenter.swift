import Foundation

final class MyClothingPresenter {
    private weak var view: MyClothingViewController?
    private var router: MyClothingRouter
    
    init(view: MyClothingViewController?, router: MyClothingRouter) {
        self.view = view
        self.router = router
    }
    
    func backButtonTapped() {
        router.navigateToWardrobe()
    }
    
    func addButtonTapped() {
        router.navigateToCreateClothes()
    }
    
    func showItem(clothes: Clothes) {
        router.navigateToItemScreen(clothes: clothes)
    }
    
}
