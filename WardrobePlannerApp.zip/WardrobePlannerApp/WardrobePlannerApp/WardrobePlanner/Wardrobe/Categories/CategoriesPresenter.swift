import Foundation

final class CategoriesPresenter {
    private weak var view: CategoriesViewController?
    private var router: CategoriesRouter
    
    init(view: CategoriesViewController?, router: CategoriesRouter) {
        self.view = view
        self.router = router
    }
    
    func backButtonTapped() {
        router.navigateToWardrobe()
    }
    
    func addButtonTapped(category: String) {
        ClothesDataManager.shared.addNewCategory(category: category)
    }
    
    func cellTapped(category: String) {
        router.navigateToSelectedCategory(category: category)
    }
}
