import Foundation

class CategoriesBuilder {
    static func build() -> CategoriesViewController {
        
        let vc = CategoriesViewController()
        let router = CategoriesRouter(view: vc)
        let presenter = CategoriesPresenter(view: vc, router: router)
        
        vc.presenter = presenter
        
        return vc
    }
}
