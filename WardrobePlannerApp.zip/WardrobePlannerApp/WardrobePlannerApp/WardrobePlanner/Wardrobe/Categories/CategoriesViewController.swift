import UIKit
import Firebase
import FirebaseFirestore

final class CategoriesViewController: UIViewController, UITextFieldDelegate {
    
    // MARK: - Fields
    var presenter: CategoriesPresenter!
    
    private let collectionView: UICollectionView = UICollectionView(frame: .zero, collectionViewLayout: UICollectionViewFlowLayout())
    
    var categories: [String] = []
    
    let categoryNameField: UITextField = UITextField()
    
    
    // MARK: - Lyfecycle
    override func viewDidLoad() {
        super.viewDidLoad()
        self.hideKeyboardWhenTappedAround()
        
        configureUI()
    }
    
    
    // MARK: - Actions
    @objc
    private func backButtonTapped() {
        presenter?.backButtonTapped()
    }
    
    @objc
    private func addTapped() {
        if let newCategory = categoryNameField.text, newCategory != "" {
            presenter?.addButtonTapped(category: newCategory)
        } else {
            return
        }
    }
    
}

extension CategoriesViewController {
    
    // MARK: - Configurations
    private func configureUI() {
        navigationItem.hidesBackButton = true
        view.backgroundColor = ColorsConstants.background
        
        configureBackButton()
        configureAddButton()
        configureCategoryField()
        configureCollection { Bool in
            if Bool == true {
                self.addCategoryToCollectionView()
                self.view.addSubview(self.collectionView)
                self.collectionView.pinHorizontal(to: self.view, 10)
                self.collectionView.pinBottom(to: self.view.safeAreaLayoutGuide.bottomAnchor)
                self.collectionView.pinTop(to: self.categoryNameField.bottomAnchor, 25)
            }
        }
    }
    
    // MARK: - Text Fields
    private func configureCategoryField() {
        view.addSubview(categoryNameField)
        categoryNameField.translatesAutoresizingMaskIntoConstraints = false
        
        categoryNameField.delegate = self
        
        categoryNameField.backgroundColor = .systemGray6
        categoryNameField.placeholder = "Enter category name"
        categoryNameField.font = UIFont.systemFont(ofSize: 18, weight: .bold)
        categoryNameField.layer.cornerRadius = 15
        categoryNameField.returnKeyType = .done
        
        categoryNameField.autocapitalizationType = .none
        categoryNameField.autocorrectionType = .no
        
        categoryNameField.leftView = UIView(frame: CGRect(x: .zero, y: .zero, width: 20, height: 50))
        categoryNameField.rightView = UIView(frame: CGRect(x: .zero, y: .zero, width: 20, height: 50))
        categoryNameField.leftViewMode = .always
        categoryNameField.rightViewMode = .always
        
        categoryNameField.setWidth(350)
        categoryNameField.setHeight(50)
        categoryNameField.pinTop(to: view.safeAreaLayoutGuide.topAnchor)
        categoryNameField.pinCenterX(to: view.centerXAnchor)
    }
    
    // MARK: - Buttons
    private func configureBackButton() {
        let largeFont = UIFont.systemFont(ofSize: 20, weight: .bold)
        let configuration = UIImage.SymbolConfiguration(font: largeFont)
        let image = UIImage(systemName: "chevron.left", withConfiguration: configuration)
        navigationItem.leftBarButtonItem = UIBarButtonItem(image: image, style: .plain, target: self, action: #selector(backButtonTapped))
        navigationItem.leftBarButtonItem?.tintColor = .black
    }
    
    private func configureAddButton() {
        let largeFont = UIFont.systemFont(ofSize: 20, weight: .bold)
        let configuration = UIImage.SymbolConfiguration(font: largeFont)
        let image = UIImage(systemName: "plus", withConfiguration: configuration)
        navigationItem.rightBarButtonItem = UIBarButtonItem(image: image, style: .plain, target: self, action: #selector(addTapped))
        navigationItem.rightBarButtonItem?.tintColor = .black
    }
    
    // MARK: - TableView
    func configureCollection(completion: @escaping (Bool) -> Void) {
        collectionView.reloadData()
        let currId = (Auth.auth().currentUser?.uid)!
        let collectionns = Firestore.firestore().collection("user").document(currId).collection("categories")
        collectionns.order(by: "name", descending: true).getDocuments {(querySnapshot, error) in
            if let error = error {
                print("Ошибка получения документов: \(error.localizedDescription)")
                completion(false)
            } else {
                var categoryModel: [String] = []
                
                for document in querySnapshot!.documents {
                    let data = document.data()
                    if !data.isEmpty {
                        let name = data["name"] as! String
                        categoryModel.append(name)
                    }
                }
                self.categories = categoryModel.sorted() 
                completion(true)
            }
        }
    }

    private func addCategoryToCollectionView() {
    
        collectionView.delegate = self
        collectionView.dataSource = self
        collectionView.alwaysBounceVertical = true
        collectionView.showsVerticalScrollIndicator = false
        collectionView.backgroundColor = ColorsConstants.background
        
        if let layout = collectionView.collectionViewLayout as? UICollectionViewFlowLayout {
            layout.minimumInteritemSpacing = 5
            layout.minimumLineSpacing = 5
            layout.invalidateLayout()
        }
        
        collectionView.register(CategoryCell.self, forCellWithReuseIdentifier: "category")
    }
}
    
extension CategoriesViewController: UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return categories.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: CategoryCell.reuseId, for: indexPath)
        
        guard let categoryCell = cell as? CategoryCell else {
            return cell
        }
        
        let category = categories[indexPath.row]
        categoryCell.configure(with: category)
        
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: UIScreen.main.bounds.width * 0.8, height: 70)
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let category = categories[indexPath.item]
        presenter.cellTapped(category: category)
        print("Cell tapped at index \(indexPath.item)")
    }
}
