import UIKit

final class WardrobeRouter {
    
    private weak var view: UIViewController?
    
    init(view: UIViewController) {
        self.view = view
    }
    
    func navigateToAddingClothes() {
        let vc = AddClothesBuilder.build()
        view?.navigationController?.pushViewController(vc, animated: true)
    }
    
    func navigateToClothingView() {
        let vc = MyClothingBuilder.build()
        view?.navigationController?.pushViewController(vc, animated: true)
    }
    
    func navigateToLooksView() {
        let vc = MyLooksBuilder.build()
        view?.navigationController?.pushViewController(vc, animated: true)
    }
    
    func navigateToCategoriesView() {
        let vc = CategoriesBuilder.build()
        view?.navigationController?.pushViewController(vc, animated: true)
    }
    

}

