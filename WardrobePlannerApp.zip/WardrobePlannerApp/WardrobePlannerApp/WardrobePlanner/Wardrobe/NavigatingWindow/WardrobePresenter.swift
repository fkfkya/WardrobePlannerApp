import Foundation

final class WardrobePresenter {
    private weak var view: WardrobeViewController?
    private var router: WardrobeRouter
    
    init(view: WardrobeViewController?, router: WardrobeRouter) {
        self.view = view
        self.router = router
    }
    
    func addClothesButtonTapped() {
        router.navigateToAddingClothes()
    }
    
    func showClothingButtonTapped() {
        router.navigateToClothingView()
    }
    
    func showLooksButtonTapped() {
        router.navigateToLooksView()
    }
    
    func showCatigoriesButtonTapped() {
        router.navigateToCategoriesView()
    }
}
