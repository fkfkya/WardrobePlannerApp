import Foundation

class WardrobeBuilder {
    static func build() -> WardrobeViewController {
        
        let vc = WardrobeViewController()
        let router = WardrobeRouter(view: vc)
        let presenter = WardrobePresenter(view: vc, router: router)
        
        vc.presenter = presenter
        
        return vc
    }
}
