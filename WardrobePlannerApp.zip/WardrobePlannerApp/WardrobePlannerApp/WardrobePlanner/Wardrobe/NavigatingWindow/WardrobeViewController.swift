import UIKit

final class WardrobeViewController: UIViewController {
    
    // MARK: - Fields
    var presenter: WardrobePresenter!

    private let addClothesButton: UIButton = UIButton(type: .system)
    private let showClothingButton: UIButton = UIButton(type: .system)
    private let showLooksButton: UIButton = UIButton(type: .system)
    private let showCatigoriesButton: UIButton = UIButton(type: .system)
    
    private let numberNameLabel: UILabel = UILabel()
    private let totalNameLabel: UILabel = UILabel()
    private let numberValueLabel: UILabel = UILabel()
    private let totalValueLabel: UILabel = UILabel()
    
    // MARK: - Lyfecycle
    override func viewDidLoad() {
        super.viewDidLoad()
        
        configureUI()
    }
    
    private func configureUI() {
        navigationItem.hidesBackButton = true
        view.backgroundColor = ColorsConstants.background
        
        configureAddClothesButton()
        configureShowClothingButton()
        configureShowLooksButton()
        configureShowCatigoriesButton()
        
        configureLabels()
    }
       
    // MARK: - Actions
    @objc
    func addButtonTapped() {
        presenter.addClothesButtonTapped()
    }
    
    @objc
    func showClothingButtonTapped() {
        presenter.showClothingButtonTapped()
        self.updateLabels()
    }
    
    @objc
    func showLooksButtonTapped() {
        presenter.showLooksButtonTapped()
        self.updateLabels()
    }
    
    @objc
    func showCatigoriesButtonTapped() {
        presenter.showCatigoriesButtonTapped()
        self.updateLabels()
    }
    
    // MARK: - Labels
    private func configureLabels(){
        configureNumberNameLabel()
        configureTotalNameLabel()
        configureNumberValueLabel()
        configureTotalValueLabel()
    }
    
    // MARK: - Labels
    private func updateLabels() {
        if let value = UserDefaults.standard.object(forKey: "numberOfItems") as? String {
            numberValueLabel.text = value
            print("Прочитанное значение: \(value)")
        } else {
            print("Ошибка: Не удалось прочитать значение для ключа 'number'")
        }
        
        if let value = UserDefaults.standard.object(forKey: "total") as? String {
            totalValueLabel.text = "\(value)$"
            print("Прочитанное значение: \(value)")
        } else {
            print("Ошибка: Не удалось прочитать значение для ключа 'total'")
        }
    }
    
    private func configureNumberNameLabel() {
        view.addSubview(numberNameLabel)
        numberNameLabel.translatesAutoresizingMaskIntoConstraints = false
        
        numberNameLabel.text = "Number of items:"
        numberNameLabel.font = UIFont.systemFont(ofSize: 16, weight: .heavy)
        
        numberNameLabel.pinBottom(to: addClothesButton.topAnchor, 160)
        numberNameLabel.pinLeft(to: addClothesButton.leadingAnchor, 10)
    }
    
    private func configureTotalNameLabel() {
        view.addSubview(totalNameLabel)
        totalNameLabel.translatesAutoresizingMaskIntoConstraints = false
        
        totalNameLabel.text = "Total cost:"
        totalNameLabel.font = UIFont.systemFont(ofSize: 16, weight: .heavy)
        
        totalNameLabel.pinTop(to: numberNameLabel.safeAreaLayoutGuide.bottomAnchor, 20)
        totalNameLabel.pinLeft(to: numberNameLabel.leadingAnchor)
    }
    
    private func configureNumberValueLabel() {
        view.addSubview(numberValueLabel)
        numberValueLabel.translatesAutoresizingMaskIntoConstraints = false
        
        numberValueLabel.text = "loading..."
        if let value = UserDefaults.standard.object(forKey: "numberOfItems") as? String {
            numberValueLabel.text = "\(value)"
            print("Прочитанное значение: \(value)")
        }
        
        numberValueLabel.textColor = .white
        numberValueLabel.font = UIFont.systemFont(ofSize: 18, weight: .bold)
        
        numberValueLabel.pinCenterY(to: numberNameLabel.centerYAnchor)
        numberValueLabel.pinRight(to: addClothesButton.trailingAnchor, 10)
    }
    
    private func configureTotalValueLabel() {
        view.addSubview(totalValueLabel)
        totalValueLabel.translatesAutoresizingMaskIntoConstraints = false
        
        totalValueLabel.text = "loading..."
        if let value = UserDefaults.standard.object(forKey: "total") as? String {
            totalValueLabel.text = "\(value)$"
            print("Прочитанное значение: \(value)")
        }
        totalValueLabel.textColor = .white
        totalValueLabel.font = UIFont.systemFont(ofSize: 18, weight: .bold)
        
        totalValueLabel.pinCenterY(to: totalNameLabel.centerYAnchor)
        totalValueLabel.pinRight(to: addClothesButton.trailingAnchor, 10)
    }
    
    // MARK: - Buttons
    private func configureAddClothesButton() {
        
        view.addSubview(addClothesButton)
        addClothesButton.translatesAutoresizingMaskIntoConstraints = false
        
        addClothesButton.setTitle(WardrobeViewConstants.AddClothesButton.name, for: .normal)
        addClothesButton.setTitleColor(WardrobeViewConstants.AddClothesButton.colorTitle, for: .normal)
        addClothesButton.titleLabel?.font = UIFont.systemFont(ofSize: 20, weight: .bold)
        
        addClothesButton.backgroundColor = WardrobeViewConstants.AddClothesButton.backroungColor
        
        addClothesButton.layer.cornerRadius = WardrobeViewConstants.AddClothesButton.layerCornerRadius
        
        addClothesButton.addTarget(self, action: #selector(addButtonTapped), for: .touchUpInside)
        
        addClothesButton.pinTop(to: view.topAnchor, WardrobeViewConstants.AddClothesButton.addButtonBottom)
        addClothesButton.pinCenterX(to: view.centerXAnchor)
        addClothesButton.setHeight(WardrobeViewConstants.AddClothesButton.height)
        addClothesButton.setWidth(WardrobeViewConstants.AddClothesButton.width)
    }

    private func configureShowClothingButton() {
        
        view.addSubview(showClothingButton)
        showClothingButton.translatesAutoresizingMaskIntoConstraints = false
        
        showClothingButton.setTitle(WardrobeViewConstants.ShowClothingButton.name, for: .normal)
        showClothingButton.setTitleColor(WardrobeViewConstants.ShowClothingButton.colorTitle, for: .normal)
        showClothingButton.titleLabel?.font = UIFont.systemFont(ofSize: 20, weight: .bold)
        
        showClothingButton.backgroundColor = AddingClothesConstans.Colors.backgroundButtons
        
        showClothingButton.layer.borderColor = showClothingButton.backgroundColor?.cgColor
        showClothingButton.layer.borderWidth = WardrobeViewConstants.ShowCatigoriesButton.layerBorderWidth
        showClothingButton.layer.cornerRadius = WardrobeViewConstants.ShowCatigoriesButton.layerCornerRadius
        
        showClothingButton.addTarget(self, action: #selector(showClothingButtonTapped), for: .touchUpInside)
        
        showClothingButton.pinTop(to: addClothesButton.bottomAnchor, WardrobeViewConstants.ShowClothingButton.addButtonBottom)
        showClothingButton.pinCenterX(to: view.centerXAnchor)
        showClothingButton.setHeight(WardrobeViewConstants.ShowClothingButton.height)
        showClothingButton.setWidth(WardrobeViewConstants.ShowClothingButton.width)
    }
    
    private func configureShowLooksButton() {
        
        view.addSubview(showLooksButton)
        showLooksButton.translatesAutoresizingMaskIntoConstraints = false
        
        showLooksButton.setTitle(WardrobeViewConstants.ShowLooksButton.name, for: .normal)
        showLooksButton.setTitleColor(WardrobeViewConstants.ShowLooksButton.colorTitle, for: .normal)
        showLooksButton.titleLabel?.font = UIFont.systemFont(ofSize: 20, weight: .bold)
        
        showLooksButton.backgroundColor = AddingClothesConstans.Colors.backgroundButtons
        
        showLooksButton.layer.borderColor = showLooksButton.backgroundColor?.cgColor
        showLooksButton.layer.borderWidth = WardrobeViewConstants.ShowCatigoriesButton.layerBorderWidth
        showLooksButton.layer.cornerRadius = WardrobeViewConstants.ShowCatigoriesButton.layerCornerRadius
        
        showLooksButton.addTarget(self, action: #selector(showLooksButtonTapped), for: .touchUpInside)
        
        showLooksButton.pinTop(to: showClothingButton.bottomAnchor, WardrobeViewConstants.ShowLooksButton.addButtonBottom)
        showLooksButton.pinCenterX(to: view.centerXAnchor)
        showLooksButton.setHeight(WardrobeViewConstants.ShowLooksButton.height)
        showLooksButton.setWidth(WardrobeViewConstants.ShowLooksButton.width)
    }
    
    private func configureShowCatigoriesButton() {
        
        view.addSubview(showCatigoriesButton)
        showCatigoriesButton.translatesAutoresizingMaskIntoConstraints = false
        
        showCatigoriesButton.setTitle(WardrobeViewConstants.ShowCatigoriesButton.name, for: .normal)
        showCatigoriesButton.setTitleColor(WardrobeViewConstants.ShowCatigoriesButton.colorTitle, for: .normal)
        showCatigoriesButton.titleLabel?.font = UIFont.systemFont(ofSize: 20, weight: .bold)
        
        showCatigoriesButton.backgroundColor = AddingClothesConstans.Colors.backgroundButtons
        
        showCatigoriesButton.layer.borderColor = showCatigoriesButton.backgroundColor?.cgColor
        showCatigoriesButton.layer.borderWidth = WardrobeViewConstants.ShowCatigoriesButton.layerBorderWidth
        showCatigoriesButton.layer.cornerRadius = WardrobeViewConstants.ShowCatigoriesButton.layerCornerRadius
        
        showCatigoriesButton.addTarget(self, action: #selector(showCatigoriesButtonTapped), for: .touchUpInside)
        
        showCatigoriesButton.pinTop(to: showLooksButton.bottomAnchor, WardrobeViewConstants.ShowCatigoriesButton.addButtonBottom)
        showCatigoriesButton.pinCenterX(to: view.centerXAnchor)
        showCatigoriesButton.setHeight(WardrobeViewConstants.ShowCatigoriesButton.height)
        showCatigoriesButton.setWidth(WardrobeViewConstants.ShowCatigoriesButton.width)
    }
       
}



