import UIKit
import Firebase
import FirebaseStorage

final class MyLooksViewController: UIViewController, UITextFieldDelegate{
    
    var presenter: MyLooksPresenter!
    
    // MARK: - Fields
    private let label: UILabel = UILabel()
    
    private let addButton: UIButton = UIButton()
    
    private let refreshControl = UIRefreshControl()
    
    private let collectionView: UICollectionView = UICollectionView(frame: .zero, collectionViewLayout: UICollectionViewFlowLayout())
    
    var outfitsArray: [Outfit] = []

    
    // MARK: - LifeCycle
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationItem.hidesBackButton = true
        view.backgroundColor = ColorsConstants.background
        
        configureUI()
    }
    
    
    @objc
    private func refreshCollectionView() {
        configureCollection { Bool in
            if Bool == true {
                self.addOutfitToCollectionView()
                self.view.addSubview(self.collectionView)
                self.collectionView.pinHorizontal(to: self.view, 10)
                self.collectionView.pinBottom(to: self.view.safeAreaLayoutGuide.bottomAnchor)
                self.collectionView.pinTop(to: self.label.bottomAnchor, 15)
            }
        }
        refreshControl.endRefreshing()
    }
    
    @objc
    private func backButtonTapped() {
        presenter?.backButtonTapped()
    }
    
    @objc
    private func addTapped() {
        presenter?.addButtonTapped()
    }

}


extension MyLooksViewController {
    
    // MARK: - Configuration
    private func configureUI() {
        configureBackButton()
        configureLabel()
        configureAddButton()
        configureCollection { Bool in
            if Bool == true {
                self.addOutfitToCollectionView()
                self.view.addSubview(self.collectionView)
                self.collectionView.pinHorizontal(to: self.view, 10)
                self.collectionView.pinBottom(to: self.view.safeAreaLayoutGuide.bottomAnchor)
                self.collectionView.pinTop(to: self.label.bottomAnchor, 15)
            }
        }
    }
    
    // MARK: - Buttons
    
    private func configureBackButton() {
        let largeFont = UIFont.systemFont(ofSize: 20, weight: .bold)
        let configuration = UIImage.SymbolConfiguration(font: largeFont)
        let image = UIImage(systemName: "chevron.left", withConfiguration: configuration)
        navigationItem.leftBarButtonItem = UIBarButtonItem(image: image, style: .plain, target: self, action: #selector(backButtonTapped))
        navigationItem.leftBarButtonItem?.tintColor = .black
    }
    
    private func configureAddButton() {
        
        let largeFont = UIFont.systemFont(ofSize: 20, weight: .bold)
        let configuration = UIImage.SymbolConfiguration(font: largeFont)
        let image = UIImage(systemName: "plus", withConfiguration: configuration)
        navigationItem.rightBarButtonItem = UIBarButtonItem(image: image, style: .plain, target: self, action: #selector(addTapped))
        navigationItem.rightBarButtonItem?.tintColor = .black
    }
    
    private func configureLabel() {
        view.addSubview(label)
        label.translatesAutoresizingMaskIntoConstraints = false
        
        label.text = "My Looks"
        label.font = UIFont.systemFont(ofSize: ProfileConstants.Sizes.photoLabel, weight: .heavy)
        
        label.pinTop(to: view.safeAreaLayoutGuide.topAnchor, -40)
        label.pinCenterX(to: view.centerXAnchor)
    }
    
    // MARK: - Collection
    func configureCollection(completion: @escaping (Bool) -> Void) {
        refreshControl.addTarget(self, action: #selector(refreshCollectionView), for: .valueChanged)
        collectionView.addSubview(refreshControl)
        collectionView.alwaysBounceVertical = true
        
        collectionView.reloadData()
        let currId = (Auth.auth().currentUser?.uid)!
        let collectionns = Firestore.firestore().collection("user").document(currId).collection("outfit")
        collectionns.order(by: "name", descending: true).getDocuments {(querySnapshot, error) in
            if let error = error {
                print("Ошибка получения документов: \(error.localizedDescription)")
                completion(false)
            } else {
                
                var outfitModel: [Outfit] = []
                let dispatchGroup = DispatchGroup()
                
                for document in querySnapshot!.documents {
                    let data = document.data()
                    if !data.isEmpty {
                        let name = data["name"] as! String
                        let description = data["description"] as! String
                        let wish = data["wish"] as! Bool
                        var images: [UIImage] = []
                        
                        let storageRef = Storage.storage().reference().child("users_pictures/\(currId)/outfits/\(name)/0.jpg")
                        
                        
                        dispatchGroup.enter()
                        storageRef.getData(maxSize: 10 * 1024 * 1024) { dataImage, error in
                            defer {
                                dispatchGroup.leave()
                            }
                            if let error = error {
                                print("Ошибка загрузки фотографии из Firebase Storage: \(error.localizedDescription)")
                            } else {
                                if let imageData = dataImage, let image = UIImage(data: imageData) {
                                    images.append(image)
                                    let newItem = Outfit(clothes: images, name: name, description: description, wish: wish)
                                    outfitModel.append(newItem)
                                } else {
                                    print("Не удалось преобразовать данные в изображение")
                                }
                            }
                        }
                    }
                }
                dispatchGroup.notify(queue: .main) {
                    print("Все фотографии успешно загружены")
                    self.outfitsArray = outfitModel.sorted { (firstItem: Outfit, secondItem: Outfit) -> Bool in
                        return firstItem.name > secondItem.name
                    }
                    
                    completion(true)
                }
            }
        }
    }

    private func addOutfitToCollectionView() {
    
        collectionView.delegate = self
        collectionView.dataSource = self
        collectionView.alwaysBounceVertical = true
        collectionView.showsVerticalScrollIndicator = false
        collectionView.backgroundColor = ColorsConstants.background
        
        if let layout = collectionView.collectionViewLayout as? UICollectionViewFlowLayout {
            layout.minimumInteritemSpacing = 5
            layout.minimumLineSpacing = 5
            layout.invalidateLayout()
        }
        
        collectionView.register(OutfitCell.self, forCellWithReuseIdentifier: "outfit")
    }

}

extension MyLooksViewController: UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return outfitsArray.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: OutfitCell.reuseId, for: indexPath)
        
        guard let outfitCell = cell as? OutfitCell else {
            return cell
        }
        
        let outfits = outfitsArray[indexPath.row]
        outfitCell.configure(with: outfits)
        
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: UIScreen.main.bounds.width / 2.2, height: 200)
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let outfit = outfitsArray[indexPath.item]
        presenter.showItem(outfit: outfit)
        print("Cell tapped at index \(indexPath.item)")
    }
}
