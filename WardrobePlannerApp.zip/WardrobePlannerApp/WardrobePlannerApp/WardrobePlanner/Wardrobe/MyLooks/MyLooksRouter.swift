import UIKit

final class MyLooksRouter {
    
    private weak var view: UIViewController?
    
    init(view: UIViewController) {
        self.view = view
    }
    
    func navigateToWardrobe() {
        view?.navigationController?.popViewController(animated: true)
    }
    
    func navigateToCreateClothes() {
        let vc = CreateLookBuilder.build()
        
        view?.navigationController?.pushViewController(vc, animated: true)
    }

    func navigateToItemScreen(outfit: Outfit) {
        let vc = CheckOutfitBuilder.build(outfit: outfit)
        view?.navigationController?.pushViewController(vc, animated: true)
    }
}

