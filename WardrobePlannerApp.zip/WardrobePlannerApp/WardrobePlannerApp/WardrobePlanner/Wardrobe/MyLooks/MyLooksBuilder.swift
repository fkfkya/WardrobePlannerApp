import Foundation

class MyLooksBuilder {
    static func build() -> MyLooksViewController {
        
        let vc = MyLooksViewController()
        let router = MyLooksRouter(view: vc)
        let presenter = MyLooksPresenter(view: vc, router: router)
        
        vc.presenter = presenter
        
        return vc
    }
}
