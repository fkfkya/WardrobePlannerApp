import Foundation

final class MyLooksPresenter {
    private weak var view: MyLooksViewController?
    private var router: MyLooksRouter
    
    init(view: MyLooksViewController?, router: MyLooksRouter) {
        self.view = view
        self.router = router
    }
    
    func backButtonTapped() {
        router.navigateToWardrobe()
    }
    
    func addButtonTapped() {
        router.navigateToCreateClothes()
    }
    
    func showItem(outfit: Outfit) {
        router.navigateToItemScreen(outfit: outfit)
    }
    
}
