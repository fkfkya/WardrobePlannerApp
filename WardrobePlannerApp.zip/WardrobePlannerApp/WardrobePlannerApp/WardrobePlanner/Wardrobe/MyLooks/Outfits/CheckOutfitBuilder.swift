import Foundation

class CheckOutfitBuilder {
    static func build(outfit: Outfit) -> CheckOutfitViewController {
        
        let vc = CheckOutfitViewController(outfit: outfit)
        let router = CheckOutfitRouter(view: vc)
        let presenter = CheckOutfitPresenter(view: vc, router: router)
        
        vc.presenter = presenter
        
        return vc
    }
}
