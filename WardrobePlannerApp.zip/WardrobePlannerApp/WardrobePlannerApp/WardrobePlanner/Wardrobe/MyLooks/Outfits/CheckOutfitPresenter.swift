import Foundation

final class CheckOutfitPresenter {
    private weak var view: CheckOutfitViewController?
    private var router: CheckOutfitRouter
    
    init(view: CheckOutfitViewController?, router: CheckOutfitRouter) {
        self.view = view
        self.router = router
    }
    
    func backButtonTapped() {
        router.navigateToWardrobe()
    }
    
    func deleteClothes(outfitToDelete: Outfit) {
        view?.showDeleteAlert(message: "Are you sure?") {
            ClothesDataManager.shared.deleteOutfit(outfit: outfitToDelete)
            self.backButtonTapped()
        }
    }
}

