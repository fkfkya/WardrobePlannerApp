import UIKit

final class CheckOutfitRouter {
    
    private weak var view: UIViewController?
    
    init(view: UIViewController) {
        self.view = view
    }
    
    func navigateToWardrobe() {
        view?.navigationController?.popViewController(animated: true)
    }
}

