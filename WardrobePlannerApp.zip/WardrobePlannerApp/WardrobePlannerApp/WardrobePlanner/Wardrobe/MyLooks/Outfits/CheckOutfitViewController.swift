import UIKit

final class CheckOutfitViewController: UIViewController, UITextFieldDelegate, UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    
    // MARK: - Fields
    var presenter: CheckOutfitPresenter!
    
    private var outfit: Outfit
    
    private let nameField: UITextField = UITextField()
    private let descriptionField: UITextField = UITextField()
    
    private let categoryLabel: UILabel = UILabel()
    private let costLabel: UILabel = UILabel()
    private let sizeLabel: UILabel = UILabel()
    
    private let deleteButton: UIButton = UIButton(type: .system)
    private let wishButton: UIButton = UIButton(type: .system)
    private let addPhotoButton: UIButton = UIButton(type: .system)
    private let saveButton: UIButton = UIButton(type: .system)
    
    private let itemImage = UIImageView()
    
    private var picture = AddingClothesConstans.Images.thing
    
    init(outfit: Outfit) {
        self.outfit = outfit
        super.init(nibName: nil, bundle: nil)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    // MARK: - Lifecycle
    override func viewDidLoad() {
        super.viewDidLoad()
        self.hideKeyboardWhenTappedAround()
        
        configureUI()
    }
    
    
    // MARK: - Actions
    @objc
    private func backButtonTapped() {
        presenter?.backButtonTapped()
    }
    
    @objc func wishButtonTapped() {
        if wishButton.currentImage == UIImage(systemName: "heart") {
            wishButton.setImage(UIImage(systemName: "heart.fill"), for: .normal)
            outfit.wish = true
        } else {
            wishButton.setImage(UIImage(systemName: "heart"), for: .normal)
            outfit.wish = false
        }
        ClothesDataManager.shared.setWish(outfit: outfit)
    }
    
    @objc
    func deleteButtonTapped() {
        presenter?.deleteClothes(outfitToDelete: outfit)
    }
    
    func showAlert(message: String) {
        let alertController = UIAlertController(title: "Error", message: message, preferredStyle: .alert)
        let okAction = UIAlertAction(title: "OK", style: .default, handler: nil)
        alertController.addAction(okAction)
        present(alertController, animated: true, completion: nil)
    }

    func showGoodAlert(message: String, completion: (() -> Void)? = nil) {
        let alertController = UIAlertController(title: "Success!", message: message, preferredStyle: .alert)
        let okAction = UIAlertAction(title: "OK", style: .default) { _ in
            completion?()
        }
        alertController.addAction(okAction)
        present(alertController, animated: true, completion: nil)
    }
    
    func showDeleteAlert(message: String, completion: (() -> Void)? = nil) {
        let alertController = UIAlertController(title: "Deleting", message: message, preferredStyle: .alert)
        let okAction = UIAlertAction(title: "OK", style: .default) { _ in
            completion?()
        }
        let cancelAction = UIAlertAction(title: "Cancel", style: .default) {_ in
            return
        }
        alertController.addAction(okAction)
        alertController.addAction(cancelAction)
        present(alertController, animated: true, completion: nil)
    }
    
}

// MARK: - Configurations
extension CheckOutfitViewController {
    
    private func configureUI() {
        view.backgroundColor = ColorsConstants.background
    
        configureItemImage()
        configureNameField()
        configureDescriptionField()
    }
    
    // MARK: - Text Fields
    private func configureNameField() {
        view.addSubview(nameField)
        nameField.translatesAutoresizingMaskIntoConstraints = false
        
        nameField.delegate = self
        
        nameField.backgroundColor = .systemGray6
        nameField.placeholder = outfit.name
        nameField.font = UIFont.systemFont(ofSize: 18, weight: .bold)
        nameField.layer.cornerRadius = 15
        nameField.returnKeyType = .done
        
        nameField.autocapitalizationType = .none
        nameField.autocorrectionType = .no
        
        nameField.leftView = UIView(frame: CGRect(x: .zero, y: .zero, width: 20, height: 50))
        nameField.rightView = UIView(frame: CGRect(x: .zero, y: .zero, width: 20, height: 50))
        nameField.leftViewMode = .always
        nameField.rightViewMode = .always
        
        nameField.setWidth(350)
        nameField.setHeight(35)
        nameField.pinTop(to: itemImage.bottomAnchor, 20)
        nameField.pinCenterX(to: view.centerXAnchor)
    }
    
    private func configureDescriptionField() {
        view.addSubview(descriptionField)
        descriptionField.translatesAutoresizingMaskIntoConstraints = false
        
        descriptionField.delegate = self
        
        descriptionField.backgroundColor = .systemGray6
        descriptionField.placeholder = outfit.description
        descriptionField.font = UIFont.systemFont(ofSize: 18, weight: .bold)
        descriptionField.layer.cornerRadius = 15
        descriptionField.returnKeyType = .done
        
        descriptionField.autocapitalizationType = .none
        descriptionField.autocorrectionType = .no
        
        descriptionField.leftView = UIView(frame: CGRect(x: .zero, y: .zero, width: 20, height: 50))
        descriptionField.rightView = UIView(frame: CGRect(x: .zero, y: .zero, width: 20, height: 50))
        descriptionField.leftViewMode = .always
        descriptionField.rightViewMode = .always
        
        descriptionField.setWidth(400)
        descriptionField.setHeight(100)
        descriptionField.pinTop(to: nameField.bottomAnchor, 20)
        descriptionField.pinCenterX(to: view.centerXAnchor)
    }
    
    // MARK: - Labels
    private func configureWishButton() {
        view.addSubview(wishButton)
        wishButton.translatesAutoresizingMaskIntoConstraints = false
        let icon = outfit.wish ? "heart.fill" : "heart"
        wishButton.setImage(UIImage(systemName: icon), for: .normal)
        wishButton.tintColor = .red
        
        wishButton.addTarget(self, action: #selector(wishButtonTapped), for: .touchUpInside)
        
        wishButton.pinBottom(to: itemImage.bottomAnchor, 5)
        wishButton.pinLeft(to: itemImage.trailingAnchor,10)
    }
    
    private func configureBackButton() {
        let largeFont = UIFont.systemFont(ofSize: 20, weight: .bold)
        let configuration = UIImage.SymbolConfiguration(font: largeFont)
        let image = UIImage(systemName: "chevron.left", withConfiguration: configuration)
        navigationItem.leftBarButtonItem = UIBarButtonItem(image: image, style: .plain, target: self, action: #selector(backButtonTapped))
        navigationItem.leftBarButtonItem?.tintColor = .black
    }
 
    // MARK: - Images
    private func configureItemImage() {
        itemImage.image = outfit.clothes.first
        view.addSubview(itemImage)
        itemImage.translatesAutoresizingMaskIntoConstraints = false
        
        itemImage.layer.cornerRadius = 20
        itemImage.clipsToBounds = true
        
        itemImage.pinTop(to: view.safeAreaLayoutGuide.topAnchor, -30)
        itemImage.pinCenterX(to: view.centerXAnchor)
        itemImage.setHeight(260)
        itemImage.setWidth(260)
    }
    
}
