import UIKit

final class AddClothesRouter {
    
    private weak var view: UIViewController?
    
    init(view: UIViewController) {
        self.view = view
    }
    
    func navigateToWardrobe() {
        view?.navigationController?.popViewController(animated: true)
    }

    func navigateToCreateClothes() {
        let vc = CreateClothesBuilder.build()
        view?.navigationController?.pushViewController(vc, animated: true)
    }
    
    func navigateToCreateLook() {
        let vc = CreateLookBuilder.build()
        view?.navigationController?.pushViewController(vc, animated: true)
    }
}

