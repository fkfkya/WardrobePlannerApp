import UIKit
import PhotosUI

final class CreateLookViewController: UIViewController, PHPickerViewControllerDelegate, UITextFieldDelegate {
    
    var presenter: CreateLookPresenter!
    
    let nameField: UITextField = UITextField()
    let descriptionField: UITextField = UITextField()
    
    var imageView: UIImageView! = UIImageView()
    var images = [UIImage]()
    var currentIndex = 0

    private let saveButton: UIButton = UIButton(type: .system)
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.hideKeyboardWhenTappedAround()
        
        view.backgroundColor = ColorsConstants.background
        view.inputViewController?.hideKeyboardWhenTappedAround()
        navigationItem.hidesBackButton = true
        
        configureUI()
    }
    
    // MARK: - Actions
    @objc
    private func backButtonTapped() {
        presenter?.backButtonTapped()
    }
    
    @available(iOS 14.0, *)
    @objc
    func addPhoto() {
        var configuration = PHPickerConfiguration()
        configuration.selectionLimit = 0
        let picker = PHPickerViewController(configuration: configuration)
        picker.delegate = self
        present(picker, animated: true)
    }
    
    @available(iOS 14.0, *)
    func picker(_ picker: PHPickerViewController, didFinishPicking results: [PHPickerResult]) {
        dismiss(animated: true)
        
        for result in results {
            if result.itemProvider.canLoadObject(ofClass: UIImage.self) {
                result.itemProvider.loadObject(ofClass: UIImage.self) { (image, error) in
                    if let image = image as? UIImage {
                        DispatchQueue.main.async {
                            self.images.append(self.cropImage(image: image) ?? image)
                            if self.currentIndex == 0 {
                                self.imageView.image = image
                            }
                        }
                    }
                }
            }
        }
    }
    
    @objc
    private func saveButtonTapped() {
        if let name = nameField.text, !name.isEmpty {
            let description = descriptionField.text ?? ""
            let savedOutfit = Outfit(clothes: images, name: name, description: description)
            presenter.saveLook(lookToSave: savedOutfit)
            return
        }
        self.showAlert(message: "Fiil all necessary fields!")
        return
    }
    
    @objc func showNextPhoto() {
        if currentIndex < images.count - 1 {
            currentIndex += 1
            UIView.transition(with: imageView, duration: 0.5, options: .transitionCrossDissolve, animations: {
                self.imageView.image = self.images[self.currentIndex]
            }, completion: nil)
        }
    }

    
    @objc
    func showPreviousPhoto() {
        if currentIndex > 0 {
            currentIndex -= 1
            UIView.transition(with: imageView, duration: 0.5, options: .transitionCrossDissolve, animations: {
                self.imageView.image = self.images[self.currentIndex]
            }, completion: nil)
        }
    }
    
    // MARK: - Functions
    func cropImage(image: UIImage) -> UIImage? {
        let cgImage = image.cgImage!
        let width = CGFloat(cgImage.width)
        let height = CGFloat(cgImage.height)
        let squareSize = min(width, height)
        let x = (width - squareSize) / 2.0
        let y = (height - squareSize) / 2.0
        let cropRect = CGRect(x: x, y: y, width: squareSize, height: squareSize)
        if let croppedCGImage = cgImage.cropping(to: cropRect) {
            return UIImage(cgImage: croppedCGImage, scale: image.scale, orientation: image.imageOrientation)
        }
        return nil
    }

    
    func showAlert(message: String) {
        let alertController = UIAlertController(title: "Error", message: message, preferredStyle: .alert)
        let okAction = UIAlertAction(title: "OK", style: .default, handler: nil)
        alertController.addAction(okAction)
        present(alertController, animated: true, completion: nil)
    }
    
    func showGoodAlert(message: String, completion: (() -> Void)? = nil) {
        let alertController = UIAlertController(title: "Success!", message: message, preferredStyle: .alert)
        let okAction = UIAlertAction(title: "OK", style: .default) { _ in
            completion?()
        }
        alertController.addAction(okAction)
        present(alertController, animated: true, completion: nil)
    }
    
}

extension CreateLookViewController {
    
    // MARK: - Configurations
    func configureUI() {
        configureButtons()
        configureItemImage()
        configureLabels()
    }
    
    // MARK: - Labels
    private func configureLabels() {
        configureNameField()
        configureDescriptionField()
    }
    private func configureDescriptionField() {
        view.addSubview(descriptionField)
        descriptionField.translatesAutoresizingMaskIntoConstraints = false
        
        descriptionField.delegate = self
        
        descriptionField.backgroundColor = .systemGray6
        descriptionField.placeholder = "Description (Optional)"
        descriptionField.font = UIFont.systemFont(ofSize: 18, weight: .bold)
        descriptionField.layer.cornerRadius = 15
        descriptionField.returnKeyType = .done
        
        descriptionField.autocapitalizationType = .none
        descriptionField.autocorrectionType = .no
        
        descriptionField.leftView = UIView(frame: CGRect(x: .zero, y: .zero, width: 20, height: 50))
        descriptionField.rightView = UIView(frame: CGRect(x: .zero, y: .zero, width: 20, height: 50))
        descriptionField.leftViewMode = .always
        descriptionField.rightViewMode = .always
        
        descriptionField.setWidth(350)
        descriptionField.setHeight(35)
        descriptionField.pinTop(to: nameField.bottomAnchor, 20)
        descriptionField.pinCenterX(to: view.centerXAnchor)
    }
    
    private func configureNameField() {
        view.addSubview(nameField)
        nameField.translatesAutoresizingMaskIntoConstraints = false
        
        nameField.delegate = self
        
        nameField.backgroundColor = .systemGray6
        nameField.placeholder = "Name of item"
        nameField.font = UIFont.systemFont(ofSize: 18, weight: .bold)
        nameField.layer.cornerRadius = 15
        nameField.returnKeyType = .done
        
        nameField.autocapitalizationType = .none
        nameField.autocorrectionType = .no
        
        nameField.leftView = UIView(frame: CGRect(x: .zero, y: .zero, width: 20, height: 50))
        nameField.rightView = UIView(frame: CGRect(x: .zero, y: .zero, width: 20, height: 50))
        nameField.leftViewMode = .always
        nameField.rightViewMode = .always
        
        nameField.setWidth(350)
        nameField.setHeight(35)
        nameField.pinTop(to: imageView.bottomAnchor, 20)
        nameField.pinCenterX(to: view.centerXAnchor)
    }
    // MARK: - Buttons
    private func configureButtons() {
        configureBackButton()
        configureAddButton()
        configureSaveButton()
    }
    
    private func configureBackButton() {
        let largeFont = UIFont.systemFont(ofSize: 20, weight: .bold)
        let configuration = UIImage.SymbolConfiguration(font: largeFont)
        let image = UIImage(systemName: "chevron.left", withConfiguration: configuration)
        navigationItem.leftBarButtonItem = UIBarButtonItem(image: image, style: .plain, target: self, action: #selector(backButtonTapped))
        navigationItem.leftBarButtonItem?.tintColor = .black
    }
    
    private func configureAddButton() {
        let largeFont = UIFont.systemFont(ofSize: 20, weight: .bold)
        let configuration = UIImage.SymbolConfiguration(font: largeFont)
        let image = UIImage(systemName: "plus", withConfiguration: configuration)
        if #available(iOS 14.0, *) {
            navigationItem.rightBarButtonItem = UIBarButtonItem(image: image, style: .plain, target: self, action: #selector(addPhoto))
        } else {
        }
        navigationItem.rightBarButtonItem?.tintColor = .black
    }
    
    private func configureSaveButton() {
        view.addSubview(saveButton)
        saveButton.translatesAutoresizingMaskIntoConstraints = false
        
        saveButton.setTitle("Save", for: .normal)
        saveButton.setTitleColor(UIColor(named: "customPurple"), for: .normal)
        saveButton.titleLabel?.font = UIFont.systemFont(ofSize: 20, weight: .bold)
        saveButton.layer.borderColor = UIColor(named: "customPurple")?.cgColor
        saveButton.layer.borderWidth = AuthConstants.registerBorderWidth
        saveButton.layer.cornerRadius = 17
        
        saveButton.addTarget(self, action: #selector(saveButtonTapped), for: .touchUpInside)
        
        saveButton.pinBottom(to: view.safeAreaLayoutGuide.bottomAnchor, 50)
        saveButton.pinCenterX(to: view.centerXAnchor)
        saveButton.setHeight(35)
        saveButton.setWidth(175)
    }
    // MARK: - Image
    private func configureItemImage() {
        view.addSubview(imageView)
        imageView.translatesAutoresizingMaskIntoConstraints = false
        imageView.isUserInteractionEnabled = true
        
        imageView.layer.cornerRadius = 20
        imageView.clipsToBounds = true
        
        imageView.pinTop(to: view.safeAreaLayoutGuide.topAnchor, -30)
        imageView.pinCenterX(to: view.centerXAnchor)
        imageView.setHeight(260)
        imageView.setWidth(260)
        
        let swipeLeft = UISwipeGestureRecognizer(target: self, action: #selector(showNextPhoto))
        swipeLeft.direction = .left
        imageView.addGestureRecognizer(swipeLeft)
        
        let swipeRight = UISwipeGestureRecognizer(target: self, action: #selector(showPreviousPhoto))
        swipeRight.direction = .right
        imageView.addGestureRecognizer(swipeRight)
        
    }

}
