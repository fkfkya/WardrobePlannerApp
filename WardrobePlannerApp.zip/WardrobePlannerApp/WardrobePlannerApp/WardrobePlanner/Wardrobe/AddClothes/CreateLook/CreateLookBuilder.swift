import Foundation

class CreateLookBuilder {
    static func build() -> CreateLookViewController {
        
        let vc = CreateLookViewController()
        let router = CreateLookRouter(view: vc)
        let presenter = CreateLookPresenter(view: vc, router: router)
        
        vc.presenter = presenter
        
        return vc
    }
}
