import UIKit

final class CreateLookRouter {
    
    private weak var view: UIViewController?
    
    init(view: UIViewController) {
        self.view = view
    }
    
    func navigateToAdding() {
        view?.navigationController?.popViewController(animated: true)
    }

}

