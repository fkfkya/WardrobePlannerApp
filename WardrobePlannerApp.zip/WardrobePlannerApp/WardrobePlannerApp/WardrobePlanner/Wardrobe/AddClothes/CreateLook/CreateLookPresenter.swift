import Foundation

final class CreateLookPresenter {
    private weak var view: CreateLookViewController?
    private var router: CreateLookRouter
    
    init(view: CreateLookViewController?, router: CreateLookRouter) {
        self.view = view
        self.router = router
    }
    
    func backButtonTapped() {
        router.navigateToAdding()
    }
    
    func saveLook(lookToSave: Outfit) {
        ClothesDataManager.shared.addOutfit(outfit: lookToSave)
        view?.showGoodAlert(message: "Clothes has been added succesfully!"){
            self.backButtonTapped()
        }
    }

    
}
