import Foundation

class AddClothesBuilder {
    static func build() -> AddClothesViewController {
        
        let vc = AddClothesViewController()
        let router = AddClothesRouter(view: vc)
        let presenter = AddClothesPresenter(view: vc, router: router)
        
        vc.presenter = presenter
        
        return vc
    }
}
