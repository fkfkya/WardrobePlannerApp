import UIKit

final class AddClothesViewController: UIViewController, UITextFieldDelegate {
    
    // MARK: - Vars
    var presenter: AddClothesPresenter!
    
    private let mainLabel: UILabel = UILabel()
    private let addThingLabel: UILabel = UILabel()
    private let addLookLabel: UILabel = UILabel()
    
    private let addThingButton: UIButton = UIButton(type: .system)
    private let createLookButton: UIButton = UIButton(type: .system)
    
    private let clothesImage = UIImageView(image: AddingClothesConstans.Images.thing)
    private let hangerImage = UIImageView(image: AddingClothesConstans.Images.hanger)
    
    // MARK: - Lifecycle
    override func viewDidLoad() {
        super.viewDidLoad()
        
        configureUI()
    }
    
    @objc
    private func backButtonTapped() {
        presenter?.backButtonTapped()
    }
    
    @objc
    private func addThingButtonTapped() {
        presenter?.addThingButtonTapped()
    }
    
    @objc
    private func createLookButtonTapped() {
        presenter?.createLookButtonTapped()
    }
    
}


// MARK: - Configurations
extension AddClothesViewController {
    
    private func configureUI() {
        navigationItem.hidesBackButton = true
        view.backgroundColor = ColorsConstants.background
        
        configureLabels()
        configureButtons()
        configureImages()
    }
    
    // MARK: - Labels
    private func configureLabels() {
        configureMainLabel()
        configureAddThingLabel()
        configureCreateLookLabel()
    }
    
    private func configureMainLabel() {
        view.addSubview(mainLabel)
        mainLabel.translatesAutoresizingMaskIntoConstraints = false
        
        mainLabel.text = AddingClothesConstans.Names.mainLabel
        mainLabel.font = UIFont.systemFont(ofSize: AddingClothesConstans.Sizes.mainLabelOf, weight: .heavy)
        
        mainLabel.pinTop(to: view.topAnchor, AddingClothesConstans.Sizes.mainLabelTop)
        mainLabel.pinCenterX(to: view.centerXAnchor)
    }
    
    private func configureAddThingLabel() {
        view.addSubview(addThingLabel)
        addThingLabel.translatesAutoresizingMaskIntoConstraints = false
        
        addThingLabel.text = AddingClothesConstans.Names.addThingLabel
        addThingLabel.font = UIFont.systemFont(ofSize: AddingClothesConstans.Sizes.addThingLabelOf, weight: .heavy)
        
        addThingLabel.pinTop(to: mainLabel.bottomAnchor, AddingClothesConstans.Sizes.addThingLabel)
        addThingLabel.pinCenterX(to: view.centerXAnchor, AddingClothesConstans.Sizes.indentationX)
    }
    
    private func configureCreateLookLabel() {
        view.addSubview(addLookLabel)
        addLookLabel.translatesAutoresizingMaskIntoConstraints = false
        
        addLookLabel.text = AddingClothesConstans.Names.addLookLabel
        addLookLabel.font = UIFont.systemFont(ofSize: AddingClothesConstans.Sizes.addLookLabelOf, weight: .heavy)
        
        addLookLabel.pinTop(to: addThingLabel.bottomAnchor, AddingClothesConstans.Sizes.addLookLabel)
        addLookLabel.pinCenterX(to: view.centerXAnchor, AddingClothesConstans.Sizes.indentationX)
    }
    
    
    // MARK: - Buttons
    private func configureButtons() {
        configureBackButton()
        configureAddThingButton()
        configureCreateLookButton()
    }
    
    private func configureBackButton() {
        let largeFont = UIFont.systemFont(ofSize: 20, weight: .bold)
        let configuration = UIImage.SymbolConfiguration(font: largeFont)
        let image = UIImage(systemName: "chevron.left", withConfiguration: configuration)
        navigationItem.leftBarButtonItem = UIBarButtonItem(image: image, style: .plain, target: self, action: #selector(backButtonTapped))
        navigationItem.leftBarButtonItem?.tintColor = .black
    }
    
    private func configureAddThingButton() {
        
        view.addSubview(addThingButton)
        addThingButton.translatesAutoresizingMaskIntoConstraints = false
        
        addThingButton.setTitle(AddingClothesConstans.Names.addThingButton, for: .normal)
        addThingButton.setTitleColor(AddingClothesConstans.Colors.colorTitle, for: .normal)
        addThingButton.titleLabel?.font = UIFont.systemFont(ofSize: AddingClothesConstans.Sizes.buttonTitleOfSize, weight: .bold)
        
        addThingButton.backgroundColor = AddingClothesConstans.Colors.buttonBackground
        
        addThingButton.layer.borderColor = AddingClothesConstans.Colors.buttonLayerColor.cgColor
        addThingButton.layer.borderWidth = AddingClothesConstans.Sizes.buttonLayerWidth
        addThingButton.layer.cornerRadius = AddingClothesConstans.Sizes.buttonLayerRadius
        
        addThingButton.addTarget(self, action: #selector(addThingButtonTapped), for: .touchUpInside)
        
        addThingButton.pinBottom(to: addThingLabel.bottomAnchor, AddingClothesConstans.Sizes.buttonPinBottom)
        addThingButton.pinCenterX(to: view.centerXAnchor, AddingClothesConstans.Sizes.indentationX)
        addThingButton.setHeight(AddingClothesConstans.Sizes.buttonHeight)
        addThingButton.setWidth(AddingClothesConstans.Sizes.buttonWidth)
    }
    
    private func configureCreateLookButton() {
        
        view.addSubview(createLookButton)
        createLookButton.translatesAutoresizingMaskIntoConstraints = false
        
        createLookButton.setTitle(AddingClothesConstans.Names.createLookButton, for: .normal)
        createLookButton.setTitleColor(AddingClothesConstans.Colors.colorTitle, for: .normal)
        createLookButton.titleLabel?.font = UIFont.systemFont(ofSize: AddingClothesConstans.Sizes.buttonTitleOfSize, weight: .bold)
        
        createLookButton.backgroundColor = AddingClothesConstans.Colors.buttonBackground
        
        createLookButton.layer.borderColor = AddingClothesConstans.Colors.buttonLayerColor.cgColor
        createLookButton.layer.borderWidth = AddingClothesConstans.Sizes.buttonLayerWidth
        createLookButton.layer.cornerRadius = AddingClothesConstans.Sizes.buttonLayerRadius
        
        createLookButton.addTarget(self, action: #selector(createLookButtonTapped), for: .touchUpInside)
        
        createLookButton.pinBottom(to: addLookLabel.bottomAnchor, AddingClothesConstans.Sizes.buttonPinBottom)
        createLookButton.pinCenterX(to: view.centerXAnchor, AddingClothesConstans.Sizes.indentationX)
        createLookButton.setHeight(AddingClothesConstans.Sizes.buttonHeight)
        createLookButton.setWidth(AddingClothesConstans.Sizes.buttonWidth)
    }
    
    // MARK: - Images
    private func configureImages() {
        configureClothesImage()
        configureLooksImage()
    }
    
    private func configureClothesImage() {
        view.addSubview(clothesImage)
        clothesImage.translatesAutoresizingMaskIntoConstraints = false
        
        clothesImage.pinCenterY(to: addThingLabel.bottomAnchor, AddingClothesConstans.Sizes.imageY)
        clothesImage.pinCenterX(to: addThingButton.leftAnchor, AddingClothesConstans.Sizes.imageX)
        clothesImage.setHeight(AddingClothesConstans.Sizes.imageHeight)
        clothesImage.setWidth(AddingClothesConstans.Sizes.imageHeight)
               
    }
    
    private func configureLooksImage() {
        view.addSubview(hangerImage)
        hangerImage.translatesAutoresizingMaskIntoConstraints = false
        
        hangerImage.pinCenterY(to: addLookLabel.bottomAnchor, AddingClothesConstans.Sizes.imageY)
        hangerImage.pinCenterX(to: createLookButton.leftAnchor, AddingClothesConstans.Sizes.imageX)
        hangerImage.setHeight(AddingClothesConstans.Sizes.imageHangerHeight)
        hangerImage.setWidth(AddingClothesConstans.Sizes.imageHangerHeight)
               
    }
}
