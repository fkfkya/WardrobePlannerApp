import UIKit

final class PhotoPickerViewController: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    
    // MARK: - Vars
    private let addPhotoLabel: UILabel = UILabel()
    private let restrictionsLabel: UILabel = UILabel()
    private let secondRestrictionsLabel: UILabel = UILabel()
    
    private let chooseFromGalleryButton: UIButton = UIButton(type: .system)
    private let takePhotoButton: UIButton = UIButton(type: .system)
    
    private let cameraIcon = UIImageView(image: AddingClothesConstans.PhotoPicker.camera)
    private let galleryIcon = UIImageView(image: AddingClothesConstans.PhotoPicker.gallery)
    
    private let imagePicker = UIImagePickerController()
    
    
    // MARK: - Lifecycle
    override func viewDidLoad() {
        super.viewDidLoad()
        configureUI()
    }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        configureFrame()
    }
    
    @objc
    private func selectFromGallery() {
        imagePicker.sourceType = .photoLibrary
        present(imagePicker, animated: true, completion: nil)
    }
    
    @objc 
    private func takePhoto() {
        if UIImagePickerController.isSourceTypeAvailable(.camera) {
            imagePicker.sourceType = .camera
            present(imagePicker, animated: true, completion: nil)
        } else {
            print("Camera is not available")
        }
    }
    
}

extension PhotoPickerViewController {
    // MARK: - Configure UI
    private func configureUI() {
        view.backgroundColor = .gray
        view.layer.cornerRadius = AddingClothesConstans.PhotoPicker.mainRadius
        
        configureMainLabel()
        configureTakePhotoButton()
        configureRestrictionsLabel()
        configureChooseFromGalleryButton()
        configureSecondRestrictionsLabel()
        configureCameraIcon()
        configureGalleryIcon()
    }
    
    private func configureFrame() {
        let modalHeight: CGFloat = view.frame.height / 2.5
        
        view.frame = CGRect(x: 0, y: view.frame.height - modalHeight, width: view.frame.width, height: modalHeight)
    }
    
    // MARK: - Buttons
    private func configureTakePhotoButton() {
        view.addSubview(takePhotoButton)
        takePhotoButton.translatesAutoresizingMaskIntoConstraints = false
        
        takePhotoButton.setTitle(AddingClothesConstans.Names.takePhotoButton, for: .normal)
        takePhotoButton.setTitleColor(AddingClothesConstans.Colors.colorTitle, for: .normal)
        takePhotoButton.titleLabel?.font = UIFont.systemFont(ofSize: AddingClothesConstans.Sizes.optButtonTitleOfSize, weight: .bold)
        
        takePhotoButton.backgroundColor = AddingClothesConstans.Colors.buttonBackground
        
        takePhotoButton.layer.borderColor = AddingClothesConstans.Colors.buttonLayerColor.cgColor
        takePhotoButton.layer.borderWidth = AddingClothesConstans.Sizes.buttonLayerWidth
        takePhotoButton.layer.cornerRadius = AddingClothesConstans.Sizes.optButtonsRadius
        
        takePhotoButton.addTarget(self, action: #selector(takePhoto), for: .touchUpInside)
        
        takePhotoButton.pinTop(to: addPhotoLabel.bottomAnchor, AddingClothesConstans.Sizes.optButtonSlideY)
        takePhotoButton.pinCenterX(to: view.centerXAnchor,AddingClothesConstans.Sizes.slideX)
        takePhotoButton.setHeight(AddingClothesConstans.Sizes.optButtonHeight)
        takePhotoButton.setWidth(AddingClothesConstans.Sizes.optButtonWidth)
    }
    
    private func configureChooseFromGalleryButton() {
        view.addSubview(chooseFromGalleryButton)
        chooseFromGalleryButton.translatesAutoresizingMaskIntoConstraints = false
        
        chooseFromGalleryButton.setTitle(AddingClothesConstans.Names.chooseFromGalleryButton, for: .normal)
        chooseFromGalleryButton.setTitleColor(AddingClothesConstans.Colors.colorTitle, for: .normal)
        chooseFromGalleryButton.titleLabel?.font = UIFont.systemFont(ofSize: AddingClothesConstans.Sizes.optButtonTitleOfSize, weight: .bold)
        
        chooseFromGalleryButton.backgroundColor = AddingClothesConstans.Colors.buttonBackground
        
        chooseFromGalleryButton.layer.borderColor = AddingClothesConstans.Colors.buttonLayerColor.cgColor
        chooseFromGalleryButton.layer.borderWidth = AddingClothesConstans.Sizes.buttonLayerWidth
        chooseFromGalleryButton.layer.cornerRadius = AddingClothesConstans.Sizes.optButtonsRadius
        
        chooseFromGalleryButton.addTarget(self, action: #selector(selectFromGallery), for: .touchUpInside)
        
        chooseFromGalleryButton.pinTop(to: restrictionsLabel.bottomAnchor, AddingClothesConstans.Sizes.optOptSlideY)
        chooseFromGalleryButton.pinCenterX(to: view.centerXAnchor, AddingClothesConstans.Sizes.slideX)
        chooseFromGalleryButton.setHeight(AddingClothesConstans.Sizes.optButtonHeight)
        chooseFromGalleryButton.setWidth(AddingClothesConstans.Sizes.optButtonWidth)
    }
    
    // MARK: - Labels
    private func configureMainLabel() {
        view.addSubview(addPhotoLabel)
        addPhotoLabel.translatesAutoresizingMaskIntoConstraints = false
        
        addPhotoLabel.text = AddingClothesConstans.Names.addPhoto
        addPhotoLabel.font = UIFont.systemFont(ofSize: AddingClothesConstans.Sizes.mainLabelOf, weight: .heavy)
        
        addPhotoLabel.pinTop(to: view.topAnchor, AddingClothesConstans.Sizes.mainLabelOf)
        addPhotoLabel.pinCenterX(to: view.centerXAnchor)
    }
    
    private func configureRestrictionsLabel() {
        view.addSubview(restrictionsLabel)
        restrictionsLabel.translatesAutoresizingMaskIntoConstraints = false
        
        restrictionsLabel.textColor = AddingClothesConstans.Colors.restrictions
        restrictionsLabel.text = AddingClothesConstans.Names.restrictionsLabel
        restrictionsLabel.font = UIFont.systemFont(ofSize: AddingClothesConstans.Sizes.restrOf, weight: .heavy)
        
        restrictionsLabel.pinTop(to: takePhotoButton.bottomAnchor, AddingClothesConstans.Sizes.restrSlideY)
        restrictionsLabel.pinCenterX(to: view.centerXAnchor)
    }
    
    private func configureSecondRestrictionsLabel() {
        view.addSubview(secondRestrictionsLabel)
        secondRestrictionsLabel.translatesAutoresizingMaskIntoConstraints = false
        
        secondRestrictionsLabel.textColor = AddingClothesConstans.Colors.restrictions
        secondRestrictionsLabel.text = AddingClothesConstans.Names.restrictionsLabel
        secondRestrictionsLabel.font = UIFont.systemFont(ofSize: AddingClothesConstans.Sizes.restrOf, weight: .heavy)
        
        secondRestrictionsLabel.pinTop(to: chooseFromGalleryButton.bottomAnchor, AddingClothesConstans.Sizes.restrSlideY)
        secondRestrictionsLabel.pinCenterX(to: view.centerXAnchor)
    }
    
    // MARK: - Icons
    private func configureCameraIcon() {
        view.addSubview(cameraIcon)
        cameraIcon.translatesAutoresizingMaskIntoConstraints = false
        
        cameraIcon.pinCenterY(to: takePhotoButton.centerYAnchor)
        cameraIcon.pinCenterX(to: takePhotoButton.leftAnchor, AddingClothesConstans.PhotoPicker.iconSlide)
        cameraIcon.setHeight(AddingClothesConstans.PhotoPicker.iconHeight)
        cameraIcon.setWidth(AddingClothesConstans.PhotoPicker.iconWidth)
               
    }
    
    private func configureGalleryIcon() {
        view.addSubview(galleryIcon)
        galleryIcon.translatesAutoresizingMaskIntoConstraints = false
        
        galleryIcon.pinCenterY(to: chooseFromGalleryButton.centerYAnchor)
        galleryIcon.pinCenterX(to: chooseFromGalleryButton.leftAnchor, AddingClothesConstans.PhotoPicker.iconSlide)
        galleryIcon.setHeight(AddingClothesConstans.PhotoPicker.iconHeight)
        galleryIcon.setWidth(AddingClothesConstans.PhotoPicker.iconWidth)
               
    }
}

extension PhotoPickerViewController {
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        if let pickedImage = info[UIImagePickerController.InfoKey.editedImage] as? UIImage {
        }
        picker.dismiss(animated: true, completion: nil)
        
    }
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        picker.dismiss(animated: true, completion: nil)
    }
    
}
