import UIKit

final class CreateClothesViewController: UIViewController, UITextFieldDelegate, UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    
    // MARK: - Fields
    var presenter: CreateClothesPresenter!
    
    private let nameField: UITextField = UITextField()
    private let costField: UITextField = UITextField()
    private let descriptionField: UITextField = UITextField()
    private let sizeField: UITextField = UITextField()
    
    private let colorLabel: UILabel = UILabel()
    private let categoryLabel: UILabel = UILabel()
    
    private let addPhotoButton: UIButton = UIButton(type: .system)
    private let saveClothesButton: UIButton = UIButton(type: .system)
    private let colorButton: UIButton = UIButton(type: .system)
    private let saveButton: UIButton = UIButton(type: .system)
    
    private let itemImage = UIImageView()
    
    private var picture = AddingClothesConstans.Images.thing
    
    private var selectedColor: UIColor = .white
    
    // MARK: - Lifecycle
    override func viewDidLoad() {
        super.viewDidLoad()
        self.hideKeyboardWhenTappedAround()
        
        configureUI()
    }
    
    
    // MARK: - Actions
    @objc
    private func backButtonTapped() {
        presenter?.backButtonTapped()
    }
    
    @objc
    private func addPhotoButtonTapped() {
        let imagePicker = UIImagePickerController()
        imagePicker.delegate = self
        imagePicker.allowsEditing = true
        imagePicker.sourceType = .photoLibrary
        
        present(imagePicker, animated: true, completion: nil)
    }
    
    @objc
    private func chooseColor() {
        if #available(iOS 14.0, *) {
            let colorPicker = UIColorPickerViewController()
            colorPicker.selectedColor = UIColor.white
            colorPicker.delegate = self
            
            present(colorPicker, animated: true, completion: nil)
        } else {
        }
        
    }
    
    @objc
    private func saveButtonTapped() {
        let cost: Double
        if let text = costField.text, let number = Double(text) {
            cost = number
        } else {
            self.showAlert(message: "Incorrect fields: <cost>!")
            return
        }
        
        if let name = nameField.text, !name.isEmpty {
            if let size = sizeField.text, !size.isEmpty {
                let description = ((descriptionField.text?.isEmpty) != nil) ? "" : descriptionField.text
                let color = selectedColor
                let category = "SS23"
                let currentDate = Date()
                let dateFormatter = DateFormatter()
                dateFormatter.dateFormat = "dd.MM.yyyy HH:mm:ss"
                
                let date = dateFormatter.string(from: currentDate)
                
                let savedClothes = Clothes(color: color, size: size, category: category, name: name, cost: cost,
                                           description: description, image: picture, date: date)
                presenter.saveClothes(clothesToSave: savedClothes)
                return
            }
        }
        self.showAlert(message: "Fiil all necessary fields!")
        return
        
    }
    
    // MARK: - Functions
    
    func cropImageToSquare(image: UIImage) -> UIImage {
           let imageSize = image.size
           let shortestSide = min(imageSize.width, imageSize.height)
           let cropRect = CGRect(x: (imageSize.width - shortestSide) / 2.0,
                                 y: (imageSize.height - shortestSide) / 2.0,
                                 width: shortestSide,
                                 height: shortestSide)
           if let croppedImage = image.cgImage?.cropping(to: cropRect) {
               return UIImage(cgImage: croppedImage, scale: image.scale, orientation: image.imageOrientation)
           }
           return image
       }
    
    func showAlert(message: String) {
        let alertController = UIAlertController(title: "Error", message: message, preferredStyle: .alert)
        let okAction = UIAlertAction(title: "OK", style: .default, handler: nil)
        alertController.addAction(okAction)
        present(alertController, animated: true, completion: nil)
    }
    
    func showGoodAlert(message: String, completion: (() -> Void)? = nil) {
        let alertController = UIAlertController(title: "Success!", message: message, preferredStyle: .alert)
        let okAction = UIAlertAction(title: "OK", style: .default) { _ in
            completion?()
        }
        alertController.addAction(okAction)
        present(alertController, animated: true, completion: nil)
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
            if let selectedImage = info[.editedImage] as? UIImage {
                itemImage.image = selectedImage
                picture = selectedImage
            }
        
        picker.dismiss(animated: true, completion: nil)
        
    }
    
}


// MARK: - Configurations
extension CreateClothesViewController {
    
    private func configureUI() {
        view.backgroundColor = ColorsConstants.background
        
        configureImages()
        configureTextFields()
        configureButtons()
        configureLabels()
    }
    
    // MARK: - Text Fields
    private func configureTextFields() {
        configureNameField()
        configureSizeField()
        configureCostField()
        configureDescriptionField()
    }
    
    private func configureNameField() {
        view.addSubview(nameField)
        nameField.translatesAutoresizingMaskIntoConstraints = false
        
        nameField.delegate = self
        
        nameField.backgroundColor = .systemGray6
        nameField.placeholder = "Name of item"
        nameField.font = UIFont.systemFont(ofSize: 18, weight: .bold)
        nameField.layer.cornerRadius = 15
        nameField.returnKeyType = .done
        
        nameField.autocapitalizationType = .none
        nameField.autocorrectionType = .no
        
        nameField.leftView = UIView(frame: CGRect(x: .zero, y: .zero, width: 20, height: 50))
        nameField.rightView = UIView(frame: CGRect(x: .zero, y: .zero, width: 20, height: 50))
        nameField.leftViewMode = .always
        nameField.rightViewMode = .always
        
        nameField.setWidth(350)
        nameField.setHeight(35)
        nameField.pinTop(to: itemImage.bottomAnchor, 20)
        nameField.pinCenterX(to: view.centerXAnchor)
    }
    
    private func configureSizeField() {
        view.addSubview(sizeField)
        sizeField.translatesAutoresizingMaskIntoConstraints = false
        
        sizeField.delegate = self
        
        sizeField.backgroundColor = .systemGray6
        sizeField.placeholder = "Size"
        sizeField.font = UIFont.systemFont(ofSize: 18, weight: .bold)
        sizeField.layer.cornerRadius = 11
        sizeField.returnKeyType = .done
        
        sizeField.autocapitalizationType = .none
        sizeField.autocorrectionType = .no

        sizeField.leftView = UIView(frame: CGRect(x: .zero, y: .zero, width: 20, height: 50))
        sizeField.rightView = UIView(frame: CGRect(x: .zero, y: .zero, width: 20, height: 50))
        sizeField.leftViewMode = .always
        sizeField.rightViewMode = .always
        
        sizeField.setWidth(170)
        sizeField.setHeight(35)
        sizeField.pinTop(to: nameField.bottomAnchor, 20)
        sizeField.pinLeft(to: nameField.leadingAnchor)
    }
    
    private func configureCostField() {
        view.addSubview(costField)
        costField.translatesAutoresizingMaskIntoConstraints = false
        
        costField.delegate = self
        
        costField.backgroundColor = .systemGray6
        costField.placeholder = "Cost <$>"
        costField.font = UIFont.systemFont(ofSize: 18, weight: .bold)
        costField.layer.cornerRadius = 11
        costField.returnKeyType = .done
        
        costField.autocapitalizationType = .none
        costField.autocorrectionType = .no
        
        costField.leftView = UIView(frame: CGRect(x: .zero, y: .zero, width: 20, height: 50))
        costField.rightView = UIView(frame: CGRect(x: .zero, y: .zero, width: 20, height: 50))
        costField.leftViewMode = .always
        costField.rightViewMode = .always
        
        costField.setWidth(170)
        costField.setHeight(35)
        costField.pinTop(to: nameField.bottomAnchor, 20)
        costField.pinLeft(to: sizeField.trailingAnchor, 10)
    }
    
    private func configureDescriptionField() {
        view.addSubview(descriptionField)
        descriptionField.translatesAutoresizingMaskIntoConstraints = false
        
        descriptionField.delegate = self
        
        descriptionField.backgroundColor = .systemGray6
        descriptionField.placeholder = "Description (Optional)"
        descriptionField.font = UIFont.systemFont(ofSize: 18, weight: .bold)
        descriptionField.layer.cornerRadius = 15
        descriptionField.returnKeyType = .done
        
        descriptionField.autocapitalizationType = .none
        descriptionField.autocorrectionType = .no
        
        descriptionField.leftView = UIView(frame: CGRect(x: .zero, y: .zero, width: 20, height: 50))
        descriptionField.rightView = UIView(frame: CGRect(x: .zero, y: .zero, width: 20, height: 50))
        descriptionField.leftViewMode = .always
        descriptionField.rightViewMode = .always
        
        descriptionField.setWidth(350)
        descriptionField.setHeight(35)
        descriptionField.pinTop(to: costField.bottomAnchor, 20)
        descriptionField.pinCenterX(to: view.centerXAnchor)
    }
    
    // MARK: - Labels
    private func configureLabels() {
        configureColorLabel()
        configureCategoryLabel()
    }
    
    
    private func configureColorLabel() {
        view.addSubview(colorLabel)
        colorLabel.translatesAutoresizingMaskIntoConstraints = false
        
        colorLabel.text = "Color"
        colorLabel.font = UIFont.systemFont(ofSize: ProfileConstants.Sizes.photoLabel, weight: .heavy)
        
        colorLabel.pinTop(to: descriptionField.bottomAnchor, 20)
        colorLabel.pinLeft(to: descriptionField.leadingAnchor, 16)
    }
    
    private func configureCategoryLabel() {
        view.addSubview(categoryLabel)
        categoryLabel.translatesAutoresizingMaskIntoConstraints = false
        
        categoryLabel.text = "Category"
        categoryLabel.font = UIFont.systemFont(ofSize: ProfileConstants.Sizes.photoLabel, weight: .heavy)
        
        categoryLabel.pinTop(to: colorLabel.bottomAnchor, 20)
        categoryLabel.pinLeft(to: descriptionField.leadingAnchor, 16)
    }
    
    // MARK: - Buttons
    private func configureButtons() {
        configureBackButton()
        configureAddPhotoButton()
        configureColorButton()
        configureSaveButton()
    }
    
    private func configureBackButton() {
        let largeFont = UIFont.systemFont(ofSize: 20, weight: .bold)
        let configuration = UIImage.SymbolConfiguration(font: largeFont)
        let image = UIImage(systemName: "chevron.left", withConfiguration: configuration)
        navigationItem.leftBarButtonItem = UIBarButtonItem(image: image, style: .plain, target: self, action: #selector(backButtonTapped))
        navigationItem.leftBarButtonItem?.tintColor = .black
    }
    
    private func configureAddPhotoButton() {
        let largeFont = UIFont.systemFont(ofSize: 20, weight: .bold)
        let configuration = UIImage.SymbolConfiguration(font: largeFont)
        let image = UIImage(systemName: "camera", withConfiguration: configuration)
        navigationItem.rightBarButtonItem = UIBarButtonItem(image: image, style: .plain, target: self, action: #selector(addPhotoButtonTapped))
        navigationItem.rightBarButtonItem?.tintColor = .black
    }
    
    private func configureColorButton() {
        view.addSubview(colorButton)
        colorButton.translatesAutoresizingMaskIntoConstraints = false
        
        colorButton.setHeight(35)
        colorButton.setWidth(150)
        
        colorButton.layer.cornerRadius = 8
        colorButton.layer.borderWidth = 1.9
        colorButton.layer.borderColor = UIColor.black.cgColor
        colorButton.backgroundColor = selectedColor
        
        colorButton.addTarget(self, action: #selector(chooseColor), for: .touchUpInside)
        
        colorButton.pinCenterX(to: view.centerXAnchor, 50)
        colorButton.pinTop(to: descriptionField.bottomAnchor, 20)
    }
    
    private func configureSaveButton() {
        view.addSubview(saveButton)
        saveButton.translatesAutoresizingMaskIntoConstraints = false
        
        saveButton.setTitle("Save", for: .normal)
        saveButton.setTitleColor(UIColor(named: "customPurple"), for: .normal)
        saveButton.titleLabel?.font = UIFont.systemFont(ofSize: 20, weight: .bold)
        saveButton.layer.borderColor = UIColor(named: "customPurple")?.cgColor
        saveButton.layer.borderWidth = AuthConstants.registerBorderWidth
        saveButton.layer.cornerRadius = 17
        
        saveButton.addTarget(self, action: #selector(saveButtonTapped), for: .touchUpInside)
        
        saveButton.pinBottom(to: view.safeAreaLayoutGuide.bottomAnchor, 50)
        saveButton.pinCenterX(to: view.centerXAnchor)
        saveButton.setHeight(35)
        saveButton.setWidth(175)
    }
 
    // MARK: - Images
    private func configureImages() {
        configureItemImage()
    }
    
    private func configureItemImage() {
        itemImage.image = AddingClothesConstans.Images.thing
        view.addSubview(itemImage)
        itemImage.translatesAutoresizingMaskIntoConstraints = false
        
        itemImage.layer.cornerRadius = 20
        itemImage.clipsToBounds = true
        
        itemImage.pinTop(to: view.safeAreaLayoutGuide.topAnchor, -30)
        itemImage.pinCenterX(to: view.centerXAnchor)
        itemImage.setHeight(260)
        itemImage.setWidth(260)
    }
    
}

extension CreateClothesViewController: UIColorPickerViewControllerDelegate {
    @available(iOS 14.0, *)
    func colorPickerViewControllerDidFinish(_ viewController: UIColorPickerViewController) {
        selectedColor = viewController.selectedColor
        colorButton.backgroundColor = selectedColor
    }
    
    @available(iOS 14.0, *)
    func colorPickerViewControllerDidSelectColor(_ viewController: UIColorPickerViewController) {
        selectedColor = viewController.selectedColor
        colorButton.backgroundColor = selectedColor
    }
}
