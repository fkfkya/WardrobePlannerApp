import Foundation

class CreateClothesBuilder {
    static func build() -> CreateClothesViewController {
        
        let vc = CreateClothesViewController()
        let router = CreateClothesRouter(view: vc)
        let presenter = CreateClothesPresenter(view: vc, router: router)
        
        vc.presenter = presenter
        
        return vc
    }
}
