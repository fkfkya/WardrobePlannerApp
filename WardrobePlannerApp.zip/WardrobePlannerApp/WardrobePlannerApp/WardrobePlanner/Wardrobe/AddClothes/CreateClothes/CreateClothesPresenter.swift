import Foundation

final class CreateClothesPresenter {
    private weak var view: CreateClothesViewController?
    private var router: CreateClothesRouter
    
    init(view: CreateClothesViewController?, router: CreateClothesRouter) {
        self.view = view
        self.router = router
    }
    
    func backButtonTapped() {
        router.navigateToAdding()
    }
    
    func saveClothes(clothesToSave: Clothes) {
        ClothesDataManager.shared.addClothes(clothes: clothesToSave)
        view?.showGoodAlert(message: "Clothes has been added succesfully!"){
            self.backButtonTapped()
        }
    }

    
}
