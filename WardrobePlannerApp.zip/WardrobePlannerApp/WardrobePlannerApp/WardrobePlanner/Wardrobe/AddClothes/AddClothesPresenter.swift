import Foundation

final class AddClothesPresenter {
    private weak var view: AddClothesViewController?
    private var router: AddClothesRouter
    
    init(view: AddClothesViewController?, router: AddClothesRouter) {
        self.view = view
        self.router = router
    }
    
    func backButtonTapped() {
        router.navigateToWardrobe()
    }

    func addThingButtonTapped() {
        router.navigateToCreateClothes()
    }
    
    func createLookButtonTapped() {
        router.navigateToCreateLook()
    }
}
