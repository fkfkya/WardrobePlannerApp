import Foundation
import FirebaseAuth

final class ProfilePresenter {
    private weak var view: ProfileViewController?
    private var router: ProfileRouter
    
    init(view: ProfileViewController?, router: ProfileRouter) {
        self.view = view
        self.router = router
    }
    
    func nameButtonTapped() {
        router.navigateToChanges()
    }
    
    func emailButtonTapped() {
        router.navigateToChanges()
    }
    
    func passButtonTapped() {
        router.navigateToChanges()
    }
    
    func quitButtonTapped() {
        do {
            try Auth.auth().signOut()
            print("Пользователь успешно вышел из системы")
        } catch let signOutError as NSError {
            print("Ошибка при выходе из системы: \(signOutError.localizedDescription)")
        }
        router.navigateToWelcome()
    }
}
