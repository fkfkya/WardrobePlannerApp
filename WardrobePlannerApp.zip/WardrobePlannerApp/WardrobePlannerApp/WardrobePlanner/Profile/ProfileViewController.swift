import UIKit

final class ProfileViewController: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate {

    var presenter: ProfilePresenter?

    private let photoLabel: UILabel = UILabel()
    private let nameLabel: UILabel = UILabel()
    private let emailLabel: UILabel = UILabel()
    private let passLabel: UILabel = UILabel()
    
    private let photoButton: UIButton = UIButton(type: .system)
    private let nameButton: UIButton = UIButton(type: .system)
    private let emailButton: UIButton = UIButton(type: .system)
    private let passButton: UIButton = UIButton(type: .system)
    private let quitButton: UIButton = UIButton(type: .system)
    
    private var avatar: UIImageView = UIImageView()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        configureUI()
    }

    // MARK: - Buttons Actions
    @objc
    private func photoButtonTapped() {
        let imagePicker = UIImagePickerController()
        imagePicker.delegate = self
        imagePicker.toolbar.backgroundColor = ColorsConstants.background
        imagePicker.allowsEditing = true

        imagePicker.sourceType = .photoLibrary
        present(imagePicker, animated: true, completion: nil)
    }
    
    @objc
    private func nameButtonTapped() {
        presenter?.nameButtonTapped()
        updateName()
        updateMail()
    }
    
    @objc
    private func emailButtonTapped() {
        presenter?.emailButtonTapped()
        updateName()
        updateMail()
    }
    
    @objc
    private func passButtonTapped() {
        presenter?.passButtonTapped()
        updateName()
        updateMail()
    }
    
    @objc
    private func quitButtonTapped() {
        presenter?.quitButtonTapped()
    }
    
    // MARK: - Other funcs
    func showAlert(message: String) {
        let alertController = UIAlertController(title: "Error", message: message, preferredStyle: .alert)
        let okAction = UIAlertAction(title: "OK", style: .default, handler: nil)
        alertController.addAction(okAction)
        present(alertController, animated: true, completion: nil)
    }
    
    func emailUnderMask(email: String) -> String {
        let components = email.components(separatedBy: "@")

        if components.count == 2 {
            let login = components[0]
            let domain = components[1]

            var newLogin = ""
            if login.count >= 3 {
                newLogin = String(login.prefix(3)) + "***"
            } else {
                newLogin = String(login.prefix(login.count)) + "***"
            }
            let newEmail = newLogin + "@" + domain

            return newEmail
        } else { return email }
    }
    
    func cropImageToCircle(image: UIImage) -> UIImage? {
        UIGraphicsBeginImageContextWithOptions(image.size, false, 0.0)
        
        let path = UIBezierPath(ovalIn: CGRect(x: 0, y: 0, width: image.size.width, height: image.size.height))
        path.addClip()
        
        image.draw(in: CGRect(x: 0, y: 0, width: image.size.width, height: image.size.height))
        
        let croppedImage = UIGraphicsGetImageFromCurrentImageContext()
        
        UIGraphicsEndImageContext()
        
        return croppedImage
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
            if let selectedImage = info[.editedImage] as? UIImage {
                avatar.image = cropImageToCircle(image: selectedImage)
                if let imageData = selectedImage.jpegData(compressionQuality: 0.8) {
                        UserDefaults.standard.set(imageData, forKey: "avatar")
                }
                UserDataManager.shared.updateUserProfileWithImage(image: selectedImage)
            }
            configureAvatar()
            picker.dismiss(animated: true, completion: nil)
    }
    
    public func updateName() {
//        if let text = UserDefaults.standard.data(forKey: "username") {
//            if let stringFromData = String(data: text, encoding: .utf8) {
//                nameButton.setTitle(String(stringFromData), for: .normal)
//            }
//        }
       
        nameButton.setTitle(UserDataManager.shared.getUserName(), for: .normal)
            
    }
    
    public func updateMail() {
        emailButton.setTitle(emailUnderMask(email: UserDataManager.shared.getUserEmail()), for: .normal)
    }
}

// MARK: - Configurations
extension ProfileViewController {
    
    private func configureUI() {
        navigationItem.hidesBackButton = true
        view.backgroundColor = ColorsConstants.background
        
        configureLabels()
        configureButtons()
    }
    
    // MARK: - Labels & Avatar
    private func configureLabels() {
        configurePhotoLabel()
        configureAvatar()
        configureNameLabel()
        configureEmailLabel()
        configurePassLabel()
    }
    
    private func configurePhotoLabel() {
        view.addSubview(photoLabel)
        photoLabel.translatesAutoresizingMaskIntoConstraints = false
        
        photoLabel.text = ProfileConstants.Names.photoLabel
        photoLabel.font = UIFont.systemFont(ofSize: ProfileConstants.Sizes.photoLabel, weight: .heavy)
        
        photoLabel.pinTop(to: view.safeAreaLayoutGuide.topAnchor, 5)
        photoLabel.pinCenterX(to: view.centerXAnchor, -80)
    }
    
    private func configureAvatar() {
        if let imageData = UserDefaults.standard.data(forKey: "avatar"),
               let image = UIImage(data: imageData) {
            self.avatar.image = cropImageToCircle(image: image)
        }
        UserDataManager.shared.getUserAvatar { [weak self] image in
            guard let self = self else {return}
            if let image = image {
                self.avatar.image = cropImageToCircle(image: image)
            } else {
                self.avatar =  UIImageView(image: ProfileConstants.Images.avatar)
            }
        }
        
        view.addSubview(self.avatar)
        avatar.translatesAutoresizingMaskIntoConstraints = false
        
        avatar.pinCenterY(to: photoLabel.bottomAnchor, 140)
        avatar.pinCenterX(to: view.centerXAnchor)
        avatar.setHeight(180)
        avatar.setWidth(180)
    }
    
    private func configureNameLabel() {
        view.addSubview(nameLabel)
        nameLabel.translatesAutoresizingMaskIntoConstraints = false
        
        nameLabel.text = ProfileConstants.Names.nameLabel
        nameLabel.font = UIFont.systemFont(ofSize: ProfileConstants.Sizes.otherLabel, weight: .heavy)
        
        nameLabel.pinTop(to: avatar.bottomAnchor, 40)
        nameLabel.pinCenterX(to: photoLabel.centerXAnchor, -40)
    }
    
    private func configureEmailLabel() {
        view.addSubview(emailLabel)
        emailLabel.translatesAutoresizingMaskIntoConstraints = false
        
        emailLabel.text = ProfileConstants.Names.emailLabel
        emailLabel.font = UIFont.systemFont(ofSize: ProfileConstants.Sizes.otherLabel, weight: .heavy)
        
        emailLabel.pinTop(to: nameLabel.bottomAnchor, 20)
        emailLabel.pinLeft(to: nameLabel.leadingAnchor)
    }
    
    private func configurePassLabel() {
        view.addSubview(passLabel)
        passLabel.translatesAutoresizingMaskIntoConstraints = false
        
        passLabel.text = ProfileConstants.Names.passLabel
        passLabel.font = UIFont.systemFont(ofSize: ProfileConstants.Sizes.otherLabel, weight: .heavy)
        
        passLabel.pinTop(to: emailLabel.bottomAnchor, 20)
        passLabel.pinLeft(to: emailLabel.leadingAnchor)
    }
    
    // MARK: - Buttons
    private func configureButtons() {
        configurePhotoButton()
        configureEmailButton()
        configureNameButton()
        configurePassButton()
        configureQuitButton()
    }
    
    private func configurePhotoButton() {
        view.addSubview(photoButton)
        photoButton.translatesAutoresizingMaskIntoConstraints = false
        
        photoButton.setTitle(ProfileConstants.Names.photoButton, for: .normal)
        photoButton.setTitleColor(.gray, for: .normal)
        photoButton.titleLabel?.font = UIFont.systemFont(ofSize: ProfileConstants.Sizes.photoLabel, weight: .bold)
        
        photoButton.addTarget(self, action: #selector(photoButtonTapped), for: .touchUpInside)
        
        photoButton.pinTop(to: view.safeAreaLayoutGuide.topAnchor)
        photoButton.pinCenterX(to: view.centerXAnchor, 100)
    }
    
    private func configureNameButton() {
        view.addSubview(nameButton)
        nameButton.translatesAutoresizingMaskIntoConstraints = false
        
        updateName()
        nameButton.setTitleColor(.gray, for: .normal)
        nameButton.titleLabel?.font = UIFont.systemFont(ofSize: ProfileConstants.Sizes.otherLabel, weight: .bold)
        
        nameButton.addTarget(self, action: #selector(nameButtonTapped), for: .touchUpInside)
        
        nameButton.pinCenterY(to: nameLabel.centerYAnchor)
        nameButton.pinLeft(to: emailButton.leadingAnchor)
    }
    
    private func configureEmailButton() {
        view.addSubview(emailButton)
        emailButton.translatesAutoresizingMaskIntoConstraints = false
        
        updateMail()
        emailButton.setTitleColor(.gray, for: .normal)
        emailButton.titleLabel?.font = UIFont.systemFont(ofSize: ProfileConstants.Sizes.otherLabel, weight: .bold)
        
        emailButton.addTarget(self, action: #selector(emailButtonTapped), for: .touchUpInside)
        
        emailButton.pinCenterY(to: emailLabel.centerYAnchor)
        emailButton.pinLeft(to: emailLabel.trailingAnchor, 40)
    }
    
    private func configurePassButton() {
        view.addSubview(passButton)
        passButton.translatesAutoresizingMaskIntoConstraints = false
        
        passButton.setTitle(ProfileConstants.Names.stars, for: .normal)
        passButton.setTitleColor(.gray, for: .normal)
        passButton.titleLabel?.font = UIFont.systemFont(ofSize: ProfileConstants.Sizes.otherLabel, weight: .bold)
        
        passButton.addTarget(self, action: #selector(passButtonTapped), for: .touchUpInside)
        
        passButton.pinCenterY(to: passLabel.centerYAnchor, -1)
        passButton.pinLeft(to: emailButton.leadingAnchor)
    }
    
    private func configureQuitButton() {
        view.addSubview(quitButton)
        quitButton.translatesAutoresizingMaskIntoConstraints = false
        
        quitButton.setTitle("Log out", for: .normal)
        quitButton.setTitleColor(TabBarConstants.Colors.activeBar, for: .normal)
        quitButton.titleLabel?.font = UIFont.systemFont(ofSize: ProfileConstants.Sizes.otherLabel, weight: .bold)
        quitButton.layer.borderColor = TabBarConstants.Colors.activeBar?.cgColor
        quitButton.layer.borderWidth = 4
        quitButton.layer.cornerRadius = 26
        
        quitButton.setWidth(90)
        quitButton.setHeight(50)
        
        quitButton.addTarget(self, action: #selector(quitButtonTapped), for: .touchUpInside)
        
        quitButton.pinTop(to: passLabel.bottomAnchor, 50)
        quitButton.pinCenterX(to: view.centerXAnchor)
        
    }
}
