import UIKit

final class ChangesRouter {
    
    private weak var view: UIViewController?
    
    init(view: UIViewController) {
        self.view = view
    }
    
    func navigateToProfile() {
        view?.navigationController?.popViewController(animated: true)
    }

}

