import UIKit

final class ChangesPresenter {
    private weak var view: ChangesViewController?
    private var router: ChangesRouter
    
    init(view: ChangesViewController?, router: ChangesRouter) {
        self.view = view
        self.router = router
    }
    
    func backButtonTapped() {
        router.navigateToProfile()
    }
    
    func nameChangeButtonTapped(nameField: UITextField) {
        nameField.isEnabled = true;
        nameField.becomeFirstResponder()
    }
    
    func emailChangeButtonTapped(emailField: UITextField) {
        emailField.isEnabled = true;
        emailField.becomeFirstResponder()
    }
    
    func passwordChangeButtonTapped(passwordField: UITextField) {
        passwordField.isEnabled = true;
    }
    
    func nameAcceptButtonTapped(nameField: UITextField, newName: String) {
        UserDataManager.shared.setUserName(newName)
        nameField.isEnabled = false;
    }
    
    func emailAcceptButtonTapped(emailField: UITextField, newEmail: String, password: String) {
        UserDataManager.shared.setEmail(newEmail: newEmail, password: password)
        emailField.isEnabled = false;
    }
    
    func passwordAcceptButtonTapped(passwordField: UITextField, secondPasswordField: UITextField) {
       // presenter?.passwordAcceptButtonTapped()
        passwordField.isEnabled = false;
        secondPasswordField.isEnabled = false;
        passwordField.becomeFirstResponder()

    }
}
