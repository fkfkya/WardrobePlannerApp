import Foundation

class ChangesBuilder {
    static func build() -> ChangesViewController {
        
        let vc = ChangesViewController()
        let router = ChangesRouter(view: vc)
        let presenter = ChangesPresenter(view: vc, router: router)
        
        vc.presenter = presenter
        
        return vc
    }
}
