import UIKit

final class ChangesViewController: UIViewController, UITextFieldDelegate {
    // MARK: - Vars
    var presenter: ChangesPresenter?

    private let settingsLabel: UILabel = UILabel()
    private let nameLabel: UILabel = UILabel()
    private let emailLabel: UILabel = UILabel()
    private let passLabel: UILabel = UILabel()
    
    private let nameAcceptButton: UIButton = UIButton(type: .system)
    private let nameChangeButton: UIButton = UIButton(type: .system)
    private let emailAcceptButton: UIButton = UIButton(type: .system)
    private let emailChangeButton: UIButton = UIButton(type: .system)
    private let passwordAcceptButton: UIButton = UIButton(type: .system)
    private let passwordChangeButton: UIButton = UIButton(type: .system)
    
    private let nameField: UITextField = UITextField()
    private let emailField: UITextField = UITextField()
    private let passwordField: UITextField = UITextField()
    private let anotherPasswordField: UITextField = UITextField()
    private let secondPassField: UITextField = UITextField()
    
    // MARK: - Funcs
    override func viewDidLoad() {
        super.viewDidLoad()
        
        configureUI()
    }
    
    @objc
    private func backButtonTapped() {
        presenter?.backButtonTapped()
    }
    
    @objc
    private func nameChangeButtonTapped() {
        nameAcceptButton.isEnabled = true;
        presenter?.nameChangeButtonTapped(nameField: nameField)
    }
    
    @objc
    private func emailChangeButtonTapped() {
        emailAcceptButton.isEnabled = true;
        anotherPasswordField.isEnabled = true;
        presenter?.emailChangeButtonTapped(emailField: emailField)
    }
    
    @objc
    private func passwordChangeButtonTapped() {
        passwordAcceptButton.isEnabled = true;
        presenter?.passwordChangeButtonTapped(passwordField: passwordField)
        presenter?.passwordChangeButtonTapped(passwordField: secondPassField)
    }
    
    @objc
    private func nameAcceptButtonTapped() {
        if let newName = nameField.text {
            presenter?.nameAcceptButtonTapped(nameField: nameField, newName: newName)
        } else {
            nameField.isEnabled = false;
        }
        nameAcceptButton.isEnabled = false;
    }
    
    @objc
    private func emailAcceptButtonTapped() {
        if let newEmail = emailField.text {
            if let password = anotherPasswordField.text {
                if (newEmail.isValidEmail()) {
                    presenter?.emailAcceptButtonTapped(emailField: emailField, newEmail: newEmail, password: password)
                }
            }
        }
        emailField.isEnabled = false;
        emailAcceptButton.isEnabled = false;
        anotherPasswordField.isEnabled = false;
    }
    
    @objc
    private func passwordAcceptButtonTapped() {
        if let newPassword = secondPassField.text {
            presenter?.passwordAcceptButtonTapped(passwordField: passwordField, secondPasswordField: secondPassField)
        } else {
            passwordField.isEnabled = false;
            secondPassField.isEnabled = false;
        }
        passwordAcceptButton.isEnabled = false;
    }
    
}

extension ChangesViewController {
    // MARK: - Configure UI
    private func configureUI() {
        navigationItem.hidesBackButton = true
        view.backgroundColor = ColorsConstants.background
    
        configureBackButton()
        
        configureSettingsLabel()
        configureNameGroup()
        configureEmailGroup()
        configurePasswordGroup()
    }
    
    private func configureNameGroup() {
        configureNameLabel()
        configureNameField()
        configureNameAcceptButton()
        configureNameChangeButton()
    }
    
    private func configureEmailGroup() {
        configureEmailLabel()
        configureEmailField()
        configureAnotherPasswordField()
        configureEmailAcceptButton()
        configureEmailChangeButton()
    }
    
    private func configurePasswordGroup() {
        configurePasswordLabel()
        configurePasswordField()
        configureSecondPasswordField()
        configurePasswordAcceptButton()
        configurePasswordChangeButton()
    }
    
    
    // MARK: - Configure Labels
    private func configureSettingsLabel() {
        view.addSubview(settingsLabel)
        settingsLabel.translatesAutoresizingMaskIntoConstraints = false
        
        settingsLabel.text = "Settings"
        settingsLabel.font = UIFont.systemFont(ofSize: ProfileConstants.Sizes.photoLabel, weight: .heavy)
        
        settingsLabel.pinTop(to: view.safeAreaLayoutGuide.topAnchor, -40)
        settingsLabel.pinCenterX(to: view.centerXAnchor)
    }
    
    private func configureNameLabel() {
        view.addSubview(nameLabel)
        nameLabel.translatesAutoresizingMaskIntoConstraints = false
        
        nameLabel.text = "Change name"
        nameLabel.font = UIFont.systemFont(ofSize: ProfileConstants.Sizes.otherLabel, weight: .semibold)
        
        nameLabel.pinTop(to: settingsLabel.topAnchor, 50)
        nameLabel.pinLeft(to: view.leadingAnchor, 30)
    }
    
    private func configureEmailLabel() {
        view.addSubview(emailLabel)
        emailLabel.translatesAutoresizingMaskIntoConstraints = false
        
        emailLabel.text = "Change email"
        emailLabel.font = UIFont.systemFont(ofSize: ProfileConstants.Sizes.otherLabel, weight: .semibold)
        
        emailLabel.pinTop(to: nameAcceptButton.bottomAnchor, 20)
        emailLabel.pinLeft(to: nameLabel.leadingAnchor)
    }
    
    private func configurePasswordLabel() {
        view.addSubview(passLabel)
        passLabel.translatesAutoresizingMaskIntoConstraints = false
        
        passLabel.text = "Change password"
        passLabel.font = UIFont.systemFont(ofSize: ProfileConstants.Sizes.otherLabel, weight: .semibold)
        
        passLabel.pinTop(to: emailAcceptButton.bottomAnchor, 20)
        passLabel.pinLeft(to: nameLabel.leadingAnchor)
    }
    
    // MARK: - Configure Text Fields
    private func configureNameField() {
        view.addSubview(nameField)
        nameField.isEnabled = false
        nameField.translatesAutoresizingMaskIntoConstraints = false
        
        nameField.delegate = self
        
        nameField.backgroundColor = .systemGray6
        nameField.placeholder = UserDataManager.shared.getUserName()
        nameField.font = UIFont.systemFont(ofSize: 18, weight: .bold)
        nameField.layer.cornerRadius = 15
        nameField.returnKeyType = .done
        
        nameField.autocapitalizationType = .none
        nameField.autocorrectionType = .no
        
        nameField.leftView = UIView(frame: CGRect(x: .zero, y: .zero, width: 20, height: 50))
        nameField.rightView = UIView(frame: CGRect(x: .zero, y: .zero, width: 20, height: 50))
        nameField.leftViewMode = .always
        nameField.rightViewMode = .always
        
        nameField.setWidth(350)
        nameField.setHeight(50)
        
        nameField.pinTop(to: nameLabel.bottomAnchor, 5)
        nameField.pinCenterX(to: view.centerXAnchor)
    }
    
    private func configureEmailField() {
        view.addSubview(emailField)
        emailField.isEnabled = false
        emailField.translatesAutoresizingMaskIntoConstraints = false
        
        emailField.delegate = self
        
        emailField.backgroundColor = .systemGray6
        emailField.placeholder = UserDataManager.shared.getUserEmail()
        emailField.font = UIFont.systemFont(ofSize: 18, weight: .bold)
        emailField.layer.cornerRadius = 15
        emailField.returnKeyType = .done
        
        emailField.autocapitalizationType = .none
        emailField.autocorrectionType = .no
        emailField.keyboardType = .emailAddress
        
        emailField.leftView = UIView(frame: CGRect(x: .zero, y: .zero, width: 20, height: 50))
        emailField.rightView = UIView(frame: CGRect(x: .zero, y: .zero, width: 20, height: 50))
        emailField.leftViewMode = .always
        emailField.rightViewMode = .always
        
        emailField.setWidth(350)
        emailField.setHeight(50)
        
        emailField.pinTop(to: emailLabel.bottomAnchor, 5)
        emailField.pinCenterX(to: view.centerXAnchor)
    }
    
    private func configurePasswordField() {
        view.addSubview(passwordField)
        passwordField.isEnabled = false
        passwordField.translatesAutoresizingMaskIntoConstraints = false
        
        passwordField.isSecureTextEntry = true
        passwordField.delegate = self
        
        passwordField.backgroundColor = .systemGray6
        passwordField.placeholder = "Enter current password"
        passwordField.font = UIFont.systemFont(ofSize: 18, weight: .bold)
        passwordField.layer.cornerRadius = 15
        passwordField.returnKeyType = .done
        
        passwordField.autocapitalizationType = .none
        passwordField.autocorrectionType = .no
        
        passwordField.leftView = UIView(frame: CGRect(x: .zero, y: .zero, width: 20, height: 50))
        passwordField.rightView = UIView(frame: CGRect(x: .zero, y: .zero, width: 20, height: 50))
        passwordField.leftViewMode = .always
        passwordField.rightViewMode = .always
        
        passwordField.setWidth(350)
        passwordField.setHeight(50)
        
        passwordField.pinTop(to: passLabel.bottomAnchor, 5)
        passwordField.pinCenterX(to: view.centerXAnchor)
    }
    
    private func configureAnotherPasswordField() {
        view.addSubview(anotherPasswordField)
        anotherPasswordField.isEnabled = false
        anotherPasswordField.translatesAutoresizingMaskIntoConstraints = false
        
        anotherPasswordField.delegate = self
        anotherPasswordField.isSecureTextEntry = true
        
        anotherPasswordField.backgroundColor = .systemGray6
        anotherPasswordField.placeholder = "Enter password to change email"
        anotherPasswordField.font = UIFont.systemFont(ofSize: 18, weight: .bold)
        anotherPasswordField.layer.cornerRadius = 15
        anotherPasswordField.returnKeyType = .done
        
        anotherPasswordField.autocapitalizationType = .none
        anotherPasswordField.autocorrectionType = .no
        
        anotherPasswordField.leftView = UIView(frame: CGRect(x: .zero, y: .zero, width: 20, height: 50))
        anotherPasswordField.rightView = UIView(frame: CGRect(x: .zero, y: .zero, width: 20, height: 50))
        anotherPasswordField.leftViewMode = .always
        anotherPasswordField.rightViewMode = .always
        
        anotherPasswordField.setWidth(350)
        anotherPasswordField.setHeight(50)
        
        anotherPasswordField.pinTop(to: emailField.bottomAnchor, 20)
        anotherPasswordField.pinCenterX(to: view.centerXAnchor)
    }
    
    private func configureSecondPasswordField() {
        view.addSubview(secondPassField)
        secondPassField.isEnabled = false
        secondPassField.translatesAutoresizingMaskIntoConstraints = false
        
        secondPassField.isSecureTextEntry = true
        secondPassField.delegate = self
        
        secondPassField.backgroundColor = .systemGray6
        secondPassField.placeholder = "Enter new password"
        secondPassField.font = UIFont.systemFont(ofSize: 18, weight: .bold)
        secondPassField.layer.cornerRadius = 15
        secondPassField.returnKeyType = .done
        
        secondPassField.autocapitalizationType = .none
        secondPassField.autocorrectionType = .no
        
        secondPassField.leftView = UIView(frame: CGRect(x: .zero, y: .zero, width: 20, height: 50))
        secondPassField.rightView = UIView(frame: CGRect(x: .zero, y: .zero, width: 20, height: 50))
        secondPassField.leftViewMode = .always
        secondPassField.rightViewMode = .always
        
        secondPassField.setWidth(350)
        secondPassField.setHeight(50)
        
        secondPassField.pinTop(to: passwordField.bottomAnchor, 20)
        secondPassField.pinCenterX(to: view.centerXAnchor)
    }
    
    
    // MARK: - Configure Buttons
    private func configureBackButton() {
        let largeFont = UIFont.systemFont(ofSize: 20, weight: .bold)
        let configuration = UIImage.SymbolConfiguration(font: largeFont)
        let image = UIImage(systemName: "chevron.left", withConfiguration: configuration)
        navigationItem.leftBarButtonItem = UIBarButtonItem(image: image, style: .plain, target: self, action: #selector(backButtonTapped))
        navigationItem.leftBarButtonItem?.tintColor = .black
    }
    
    private func configureNameAcceptButton() {
        view.addSubview(nameAcceptButton)
        nameAcceptButton.isEnabled = false;
        nameAcceptButton.translatesAutoresizingMaskIntoConstraints = false
        
        nameAcceptButton.setTitle("Accept", for: .normal)
        nameAcceptButton.setTitleColor(.white, for: .normal)
        nameAcceptButton.titleLabel?.font = UIFont.systemFont(ofSize: AddingClothesConstans.Sizes.buttonTitleOfSize, weight: .bold)
        
        nameAcceptButton.backgroundColor = ColorsConstants.agreeColor
        
        nameAcceptButton.layer.cornerRadius = AddingClothesConstans.Sizes.buttonLayerRadius
        
        nameAcceptButton.addTarget(self, action: #selector(nameAcceptButtonTapped), for: .touchUpInside)
        
        nameAcceptButton.pinTop(to: nameField.bottomAnchor, ChangeConstants.indentation.buttonsY)
        nameAcceptButton.pinLeft(to: nameField.leadingAnchor, ChangeConstants.indentation.buttonLeft)
        nameAcceptButton.setHeight(AddingClothesConstans.Sizes.buttonHeight)
        nameAcceptButton.setWidth(120)
    }
    
    private func configureEmailAcceptButton() {
        view.addSubview(emailAcceptButton)
        emailAcceptButton.isEnabled = false;
        emailAcceptButton.translatesAutoresizingMaskIntoConstraints = false
        
        emailAcceptButton.setTitle("Accept", for: .normal)
        emailAcceptButton.setTitleColor(.white, for: .normal)
        emailAcceptButton.titleLabel?.font = UIFont.systemFont(ofSize: AddingClothesConstans.Sizes.buttonTitleOfSize, weight: .bold)
        
        emailAcceptButton.backgroundColor = ColorsConstants.agreeColor
        
        emailAcceptButton.layer.cornerRadius = AddingClothesConstans.Sizes.buttonLayerRadius
        
        emailAcceptButton.addTarget(self, action: #selector(emailAcceptButtonTapped), for: .touchUpInside)
        
        emailAcceptButton.pinTop(to: anotherPasswordField.bottomAnchor, ChangeConstants.indentation.buttonsY)
        emailAcceptButton.pinLeft(to: anotherPasswordField.leadingAnchor, ChangeConstants.indentation.buttonLeft)
        emailAcceptButton.setHeight(AddingClothesConstans.Sizes.buttonHeight)
        emailAcceptButton.setWidth(120)
    }
    
    private func configurePasswordAcceptButton() {
        view.addSubview(passwordAcceptButton)
        passwordAcceptButton.isEnabled = false;
        passwordAcceptButton.translatesAutoresizingMaskIntoConstraints = false
        
        passwordAcceptButton.setTitle("Accept", for: .normal)
        passwordAcceptButton.setTitleColor(.white, for: .normal)
        passwordAcceptButton.titleLabel?.font = UIFont.systemFont(ofSize: AddingClothesConstans.Sizes.buttonTitleOfSize, weight: .bold)
        
        passwordAcceptButton.backgroundColor = ColorsConstants.agreeColor
        
        passwordAcceptButton.layer.cornerRadius = AddingClothesConstans.Sizes.buttonLayerRadius
        
        passwordAcceptButton.addTarget(self, action: #selector(passwordAcceptButtonTapped), for: .touchUpInside)
        
        passwordAcceptButton.pinTop(to: secondPassField.bottomAnchor, ChangeConstants.indentation.buttonsY)
        passwordAcceptButton.pinLeft(to: secondPassField.leadingAnchor, ChangeConstants.indentation.buttonLeft)
        passwordAcceptButton.setHeight(AddingClothesConstans.Sizes.buttonHeight)
        passwordAcceptButton.setWidth(120)
    }
    
    private func configureNameChangeButton() {
        view.addSubview(nameChangeButton)
        nameChangeButton.translatesAutoresizingMaskIntoConstraints = false
        
        nameChangeButton.setTitle("Edit", for: .normal)
        nameChangeButton.setTitleColor(.white, for: .normal)
        nameChangeButton.titleLabel?.font = UIFont.systemFont(ofSize: AddingClothesConstans.Sizes.buttonTitleOfSize, weight: .bold)
        
        nameChangeButton.backgroundColor = ColorsConstants.editColor
        
        nameChangeButton.layer.cornerRadius = AddingClothesConstans.Sizes.buttonLayerRadius
        
        nameChangeButton.addTarget(self, action: #selector(nameChangeButtonTapped), for: .touchUpInside)
        
        nameChangeButton.pinTop(to: nameField.bottomAnchor, ChangeConstants.indentation.buttonsY)
        nameChangeButton.pinRight(to: nameField.trailingAnchor, ChangeConstants.indentation.buttonRight)
        nameChangeButton.setHeight(AddingClothesConstans.Sizes.buttonHeight)
        nameChangeButton.setWidth(120)
    }
    
    private func configureEmailChangeButton() {
        view.addSubview(emailChangeButton)
        emailChangeButton.translatesAutoresizingMaskIntoConstraints = false
        
        emailChangeButton.setTitle("Edit", for: .normal)
        emailChangeButton.setTitleColor(.white, for: .normal)
        emailChangeButton.titleLabel?.font = UIFont.systemFont(ofSize: AddingClothesConstans.Sizes.buttonTitleOfSize,
                                                               weight: .bold)
        
        emailChangeButton.backgroundColor = ColorsConstants.editColor
        
        emailChangeButton.layer.cornerRadius = AddingClothesConstans.Sizes.buttonLayerRadius
        
        emailChangeButton.addTarget(self, action: #selector(emailChangeButtonTapped), for: .touchUpInside)
        
        emailChangeButton.pinTop(to: anotherPasswordField.bottomAnchor, ChangeConstants.indentation.buttonsY)
        emailChangeButton.pinRight(to: anotherPasswordField.trailingAnchor, ChangeConstants.indentation.buttonRight)
        emailChangeButton.setHeight(AddingClothesConstans.Sizes.buttonHeight)
        emailChangeButton.setWidth(120)
    }
    
    private func configurePasswordChangeButton() {
        view.addSubview(passwordChangeButton)
        passwordChangeButton.translatesAutoresizingMaskIntoConstraints = false
        
        passwordChangeButton.setTitle("Edit", for: .normal)
        passwordChangeButton.setTitleColor(.white, for: .normal)
        passwordChangeButton.titleLabel?.font = UIFont.systemFont(ofSize: AddingClothesConstans.Sizes.buttonTitleOfSize, weight: .bold)
        
        passwordChangeButton.backgroundColor = ColorsConstants.editColor
        
        passwordChangeButton.layer.cornerRadius = AddingClothesConstans.Sizes.buttonLayerRadius
        
        passwordChangeButton.addTarget(self, action: #selector(passwordChangeButtonTapped), for: .touchUpInside)
        
        passwordChangeButton.pinTop(to: secondPassField.bottomAnchor, ChangeConstants.indentation.buttonsY)
        passwordChangeButton.pinRight(to: secondPassField.trailingAnchor, ChangeConstants.indentation.buttonRight)
        passwordChangeButton.setHeight(AddingClothesConstans.Sizes.buttonHeight)
        passwordChangeButton.setWidth(120)
    }
    
    
}
