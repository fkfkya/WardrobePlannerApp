import UIKit

final class ProfileRouter {
    private weak var view: UIViewController?
    
    init(view: UIViewController) {
        self.view = view
    }
    
    func navigateToChanges() {
        let vc = ChangesBuilder.build()
        view?.navigationController?.pushViewController(vc, animated: true)
    }
    
    func navigateToWelcome() {
        guard let sceneDelegate = UIApplication.shared.connectedScenes.first?.delegate as? SceneDelegate else { return }

        let newRootViewController = WelcomeBuilder.build()
        sceneDelegate.window?.rootViewController = UINavigationController(rootViewController: newRootViewController)
        sceneDelegate.window?.makeKeyAndVisible()
    }
    
}

