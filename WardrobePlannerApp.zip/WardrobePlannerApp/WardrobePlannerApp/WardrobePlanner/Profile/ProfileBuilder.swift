import Foundation

class ProfileBuilder {
    static func build() -> ProfileViewController {
        
        let vc = ProfileViewController()
        let router = ProfileRouter(view: vc)
        let presenter = ProfilePresenter(view: vc, router: router)
        
        vc.presenter = presenter
        
        return vc
    }
}
