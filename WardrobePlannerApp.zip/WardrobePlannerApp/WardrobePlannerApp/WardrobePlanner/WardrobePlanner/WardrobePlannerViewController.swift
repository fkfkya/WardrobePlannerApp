import UIKit

final class WardrobePlannerViewController: UIViewController {

    var presenter: WardrobePlannerPresenter?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        configureUI()
    }


}

extension WardrobePlannerViewController {
    
    private func configureUI() {
        navigationItem.hidesBackButton = true
        view.backgroundColor = ColorsConstants.background
        

    }
}
