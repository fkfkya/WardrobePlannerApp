import Foundation


final class WardrobePlannerPresenter {
    private weak var view: WardrobePlannerViewController?
    private var router: WardrobePlannerRouter
    
    init(view: WardrobePlannerViewController?, router: WardrobePlannerRouter) {
        self.view = view
        self.router = router
    }
}
