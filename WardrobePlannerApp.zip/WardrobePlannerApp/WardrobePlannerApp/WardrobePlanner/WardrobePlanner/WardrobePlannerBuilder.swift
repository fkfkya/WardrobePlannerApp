import Foundation

class WardrobePlannerBuilder {
    static func build() -> WardrobePlannerViewController {
        
        let vc = WardrobePlannerViewController()
        let router = WardrobePlannerRouter(view: vc)
        let presenter = WardrobePlannerPresenter(view: vc, router: router)
        
        vc.presenter = presenter
        
        return vc
    }
}
