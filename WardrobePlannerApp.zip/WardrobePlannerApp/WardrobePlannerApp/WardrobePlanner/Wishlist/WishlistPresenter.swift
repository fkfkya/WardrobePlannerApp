import Foundation

final class WishlistPresenter {
    private weak var view: WishlistViewController?
    private var router: WishlistRouter
    
    init(view: WishlistViewController?, router: WishlistRouter) {
        self.view = view
        self.router = router
    }
    
    func showWishClothes() {
        router.openClothes()
    }
    
    func showWishOutfits() {
        router.openOutfits()
    }
    
    func showItem(clothes: Clothes) {
        router.navigateToItemScreen(clothes: clothes)
    }
    
}
