import UIKit

final class WishlistRouter {
    private weak var view: WishlistViewController?
    
    init(view: WishlistViewController) {
        self.view = view
    }
    
    func openClothes() {
        view?.configureClothes()
    }
    
    func openOutfits() {
        
    }
    
    func navigateToItemScreen(clothes: Clothes) {
        let vc = ClothesBuilder.build(clothes: clothes)
        view?.navigationController?.pushViewController(vc, animated: true)
    }
    
}

