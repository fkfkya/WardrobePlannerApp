import UIKit

final class WishlistViewController: UIViewController {
    
    // MARK: - Fields
    var presenter: WishlistPresenter?
    
    let collectionView: UICollectionView = UICollectionView(frame: .zero, collectionViewLayout: UICollectionViewFlowLayout())
    
    var clothesArray: [Clothes] = []

    
    var segmentedControl: UISegmentedControl = UISegmentedControl(items: ["Clothes", "Outfits"])

    var wishlistLabel: UILabel = UILabel()
    
    // MARK: - Lyfecycle
    override func viewDidLoad() {
        super.viewDidLoad()
        
        configureUI()
    }
    
    
    // MARK: - Actions
    @objc
    func segmentedControlValueChanged(_ sender: UISegmentedControl) {
        switch sender.selectedSegmentIndex {
        case 0:
            presenter?.showWishClothes()
        case 1:
            presenter?.showWishOutfits()
        default:
            break
        }
    }
}

extension WishlistViewController {
    
    // MARK: - Configurations
    private func configureUI() {
        navigationItem.hidesBackButton = true
        view.backgroundColor = ColorsConstants.background

        configureWishLabel()
        configureSwitch()
    }
    
    // MARK: - Labels
    private func configureWishLabel() {
        view.addSubview(wishlistLabel)
        wishlistLabel.translatesAutoresizingMaskIntoConstraints = false
        
        wishlistLabel.text = "Wishlist"
        wishlistLabel.font = UIFont.systemFont(ofSize: ProfileConstants.Sizes.photoLabel, weight: .heavy)
        
        wishlistLabel.pinTop(to: view.safeAreaLayoutGuide.topAnchor, -40)
        wishlistLabel.pinCenterX(to: view.centerXAnchor)
    }
    
    
    // MARK: - Switch
    private func configureSwitch() {
        view.addSubview(segmentedControl)
        segmentedControl.translatesAutoresizingMaskIntoConstraints = false
        segmentedControl.selectedSegmentIndex = 0
        
        segmentedControl.setWidth(UIScreen.main.bounds.width / 1.5)
        
        segmentedControl.addTarget(self, action: #selector(segmentedControlValueChanged(_:)), for: .valueChanged)
           
        segmentedControl.pinTop(to: wishlistLabel.bottomAnchor, 10)
        segmentedControl.pinCenterX(to: view.centerXAnchor)
    }
    
    // MARK: - Buttons

}
