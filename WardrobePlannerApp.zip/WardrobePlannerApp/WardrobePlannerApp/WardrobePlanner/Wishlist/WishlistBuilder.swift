import Foundation

class WishlistBuilder {
    static func build() -> WishlistViewController {
        
        let vc = WishlistViewController()
        let router = WishlistRouter(view: vc)
        let presenter = WishlistPresenter(view: vc, router: router)
        
        vc.presenter = presenter
        
        return vc
    }
}
