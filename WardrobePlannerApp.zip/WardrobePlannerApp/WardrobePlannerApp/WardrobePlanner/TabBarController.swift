import UIKit

enum Tabs: Int {
    case wardrobe
    case calendar
    case wishlist
    case profile
}

final class TabBarController: UITabBarController {
    
    override init(nibName nibNameOrNil: String?, bundle nibBundleOrNil: Bundle?) {
        super.init(nibName: nibNameOrNil, bundle: nibBundleOrNil)
        
        configure()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func configure() {
        tabBar.tintColor = TabBarConstants.Colors.activeBar
        tabBar.barTintColor = TabBarConstants.Colors.inactiveBar
        tabBar.backgroundColor = TabBarConstants.Colors.bar
        tabBar.unselectedItemTintColor = TabBarConstants.Colors.inactiveBar
        
        //tabBar.layer.borderColor = TabBarConstants.Colors.separator.cgColor
        tabBar.layer.cornerRadius = TabBarConstants.Sizes.layerRadius
        //tabBar.layer.borderWidth = TabBarConstants.Sizes.borderWidth
        tabBar.layer.masksToBounds = true
        
        let wardrobeController = WardrobeBuilder.build()
        let calendarController = CalendarBuilder.build()
        let wishlistController = WishlistBuilder.build()
        let profileController = ProfileBuilder.build()
        
        let wardrobeNavigationController = UINavigationController(rootViewController: wardrobeController)
        let calendarNavigationController = UINavigationController(rootViewController: calendarController)
        let wishlistNavigationController = UINavigationController(rootViewController: wishlistController)
        let profileNavigationController = UINavigationController(rootViewController: profileController)
        
        wardrobeNavigationController.tabBarItem = UITabBarItem(title: TabBarConstants.Names.wardrobe,
                                                               image: TabBarConstants.Images.wardrobe,
                                                     tag: Tabs.wardrobe.rawValue)
        calendarNavigationController.tabBarItem = UITabBarItem(title: TabBarConstants.Names.calendar,
                                                     image: TabBarConstants.Images.calendar,
                                                     tag: Tabs.calendar.rawValue)
        wishlistNavigationController.tabBarItem = UITabBarItem(title: TabBarConstants.Names.wishlist,
                                                     image: TabBarConstants.Images.wishlist,
                                                     tag: Tabs.wishlist.rawValue)
        profileNavigationController.tabBarItem = UITabBarItem(title: TabBarConstants.Names.profile,
                                                     image: TabBarConstants.Images.profile,
                                                     tag: Tabs.profile.rawValue)
        
        setViewControllers([
            wardrobeNavigationController,
            calendarNavigationController,
            wishlistNavigationController,
            profileNavigationController
        ], animated: false)
    }
    
}
