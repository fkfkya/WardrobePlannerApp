import Foundation

class CalendarBuilder {
    static func build() -> CalendarViewController {
        
        let vc = CalendarViewController()
        let router = CalendarRouter(view: vc)
        let presenter = CalendarPresenter(view: vc, router: router)
        
        vc.presenter = presenter
        
        return vc
    }
}
