import Foundation

final class CalendarPresenter {
    private weak var view: CalendarViewController?
    private var router: CalendarRouter
    
    init(view: CalendarViewController?, router: CalendarRouter) {
        self.view = view
        self.router = router
    }
}
