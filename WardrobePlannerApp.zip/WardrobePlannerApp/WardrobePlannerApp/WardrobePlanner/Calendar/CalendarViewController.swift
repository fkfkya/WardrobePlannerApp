import UIKit
import FSCalendar

final class CalendarViewController: UIViewController, UITextFieldDelegate {
    
    var presenter: CalendarPresenter!
    
    private let eventNameField: UITextField = UITextField()
    private let eventDiscrField: UITextField = UITextField()
    
    //private var calendarManager: CalendarManager = CalendarManager()
    fileprivate weak var calendar: FSCalendar!
    
    private let addEventButton: UIButton = UIButton(type: .system)
    private let addLookButton: UIButton = UIButton(type: .system)
    
    private var selectedDate: Date?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.hideKeyboardWhenTappedAround()
        configureUI()
    }
    
    @objc
    private func addEventButtonTapped() {
        
    }
    
    @objc
    private func addLookButtonTapped() {
        
    }
}

// MARK: - Configurations
extension CalendarViewController {
    private func configureUI() {
        view.backgroundColor = ColorsConstants.background
        
        configureCalendar()
        configureEventNameField()
        configureEventDiscrField()
        configureAddEventButton()
        configureCreateLookButton()
    }
    
    
    // MARK: - Configure labels and fields
    
    private func configureEventNameField() {
        view.addSubview(eventNameField)
        eventNameField.translatesAutoresizingMaskIntoConstraints = false
        
        eventNameField.delegate = self
        
        eventNameField.backgroundColor = .systemGray6
        eventNameField.placeholder = "Event's name"
        eventNameField.font = UIFont.systemFont(ofSize: 18, weight: .bold)
        eventNameField.layer.cornerRadius = 15
        eventNameField.returnKeyType = .done
        
        eventNameField.autocapitalizationType = .none
        eventNameField.autocorrectionType = .no
        
        eventNameField.leftView = UIView(frame: CGRect(x: .zero, y: .zero, width: 20, height: 50))
        eventNameField.rightView = UIView(frame: CGRect(x: .zero, y: .zero, width: 20, height: 50))
        eventNameField.leftViewMode = .always
        eventNameField.rightViewMode = .always
        
        eventNameField.setWidth(350)
        eventNameField.setHeight(50)
        
        eventNameField.pinTop(to: view.topAnchor, 390)
        eventNameField.pinCenterX(to: view.centerXAnchor)
    }
    
    private func configureEventDiscrField() {
        view.addSubview(eventDiscrField)
        eventDiscrField.translatesAutoresizingMaskIntoConstraints = false
        
        eventDiscrField.delegate = self
        
        eventDiscrField.backgroundColor = .systemGray6
        eventDiscrField.placeholder = "Description\n"
        eventDiscrField.font = UIFont.systemFont(ofSize: 18, weight: .bold)
        eventDiscrField.layer.cornerRadius = 15
        eventDiscrField.returnKeyType = .done
        
        eventDiscrField.autocapitalizationType = .none
        eventDiscrField.autocorrectionType = .no
        
        eventDiscrField.leftView = UIView(frame: CGRect(x: .zero, y: .zero, width: 20, height: 50))
        eventDiscrField.rightView = UIView(frame: CGRect(x: .zero, y: .zero, width: 20, height: 50))
        eventDiscrField.leftViewMode = .always
        eventDiscrField.rightViewMode = .always
        
        eventDiscrField.setWidth(350)
        eventDiscrField.setHeight(90)
        eventDiscrField.pinTop(to: eventNameField.bottomAnchor, 15)
        eventDiscrField.pinCenterX(to: view.centerXAnchor)
    }
    
    
    // MARK: - Calendar
    private func configureCalendar() {
        let calendar = FSCalendar (frame: CalendarConstants.frame)
        
        calendar.dataSource = self
        calendar.delegate = self
        
        calendar.register(FSCalendarCell.self, forCellReuseIdentifier:
        "CELL")
        
        view.addSubview(calendar)
        calendar.translatesAutoresizingMaskIntoConstraints = false
        
        calendar.layer.borderWidth = CalendarConstants.layerSize
        calendar.layer.borderColor = CalendarConstants.layerColor?.cgColor
        calendar.layer.cornerRadius = CalendarConstants.LayerRadius
        
        calendar.appearance.headerTitleColor = AddingClothesConstans.Colors.restrictions
        calendar.appearance.borderRadius = CalendarConstants.daysBorderRadius
        calendar.appearance.selectionColor = CalendarConstants.layerColor
        calendar.appearance.titleSelectionColor = TabBarConstants.Colors.inactiveBar
        
        calendar.topAnchor.constraint(equalTo: view.topAnchor, constant: CalendarConstants.calendarSlideY).isActive = true
        calendar.centerXAnchor.constraint(equalTo: view.centerXAnchor).isActive = true
        calendar.heightAnchor.constraint(equalToConstant: CalendarConstants.heightAnchor).isActive = true
        calendar.widthAnchor.constraint(equalToConstant: view.frame.width - 20).isActive = true
    }
    
    // MARK: - Buttons
    private func configureAddEventButton() {
        
        view.addSubview(addEventButton)
        addEventButton.translatesAutoresizingMaskIntoConstraints = false
        
        addEventButton.setTitle("Create Event", for: .normal)
        addEventButton.setTitleColor(WardrobeViewConstants.ShowClothingButton.colorTitle, for: .normal)
        addEventButton.titleLabel?.font = UIFont.systemFont(ofSize: AddingClothesConstans.Sizes.buttonTitleOfSize, weight: .bold)
        
        addEventButton.backgroundColor = AddingClothesConstans.Colors.buttonBackground
        
        addEventButton.layer.borderColor = AddingClothesConstans.Colors.buttonLayerColor.cgColor
        addEventButton.layer.borderWidth = AddingClothesConstans.Sizes.buttonLayerWidth
        addEventButton.layer.cornerRadius = AddingClothesConstans.Sizes.buttonLayerRadius
        
        addEventButton.addTarget(self, action: #selector(addEventButtonTapped), for: .touchUpInside)
        
        addEventButton.pinTop(to: eventDiscrField.bottomAnchor, 15)
        addEventButton.pinCenterX(to: view.centerXAnchor)
        addEventButton.setHeight(AddingClothesConstans.Sizes.buttonHeight)
        addEventButton.setWidth(AddingClothesConstans.Sizes.buttonWidth)
    }
    
    private func configureCreateLookButton() {
        
        view.addSubview(addLookButton)
        addLookButton.translatesAutoresizingMaskIntoConstraints = false
        
        addLookButton.setTitle("Add Outfit", for: .normal)
        addLookButton.setTitleColor(WardrobeViewConstants.ShowClothingButton.colorTitle, for: .normal)
        addLookButton.titleLabel?.font = UIFont.systemFont(ofSize: AddingClothesConstans.Sizes.buttonTitleOfSize, weight: .bold)
        
        addLookButton.backgroundColor = AddingClothesConstans.Colors.buttonBackground
        
        addLookButton.layer.borderColor = AddingClothesConstans.Colors.buttonLayerColor.cgColor
        addLookButton.layer.borderWidth = AddingClothesConstans.Sizes.buttonLayerWidth
        addLookButton.layer.cornerRadius = AddingClothesConstans.Sizes.buttonLayerRadius
        
        addLookButton.addTarget(self, action: #selector(addLookButtonTapped), for: .touchUpInside)
        
        addLookButton.pinTop(to: addEventButton.bottomAnchor, 15)
        addLookButton.pinCenterX(to: view.centerXAnchor)
        addLookButton.setHeight(AddingClothesConstans.Sizes.buttonHeight)
        addLookButton.setWidth(AddingClothesConstans.Sizes.buttonWidth)
    }
}


// MARK: - FSCalendarDelegate, FSCalendarDataSource
extension CalendarViewController: FSCalendarDelegate, FSCalendarDataSource {

    
    func calendar(_ calendar: FSCalendar, didSelect date: Date, at monthPosition: FSCalendarMonthPosition) {
        selectedDate = date
    }
    
    func calendar(_ calendar: FSCalendar, appearance: FSCalendarAppearance, fillDefaultColorFor date: Date) -> UIColor? {

        if isEventPlanned(for: date) {
            return .green
        } else { return nil }
    }
       
    func isEventPlanned(for date: Date) -> Bool {
        return false
    }
    
}
