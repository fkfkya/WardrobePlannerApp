import Foundation

protocol LoginRouting{
    func navigateToWellcome()
    func navigateToWardrobe()
}
