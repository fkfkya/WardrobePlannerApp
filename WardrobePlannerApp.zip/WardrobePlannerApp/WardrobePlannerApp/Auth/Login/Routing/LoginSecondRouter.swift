import UIKit

final class LoginSecondRouter: LoginRouting {
    private weak var view: UIViewController?
    
    init(view: UIViewController) {
        self.view = view
    }
    
    func navigateToWellcome() {
        view?.navigationController?.popViewController(animated: true)
    }
    
    func navigateToWardrobe() {
        let vc = EnterUsernameBuilder.build()
        vc.navigationController?.isNavigationBarHidden = true
        view?.navigationController?.pushViewController(vc, animated: true)
    }
}
