import Foundation

final class EnterUsernameBuilder {
    static func build() -> EnterUsernameViewController {
        
        let vc = EnterUsernameViewController()
        let router = EnterUsernameRouter(view: vc)
        let presenter = EnterUsernamePresenter(view: vc, router: router)
        
        vc.presenter = presenter
        
        return vc
    }

}
