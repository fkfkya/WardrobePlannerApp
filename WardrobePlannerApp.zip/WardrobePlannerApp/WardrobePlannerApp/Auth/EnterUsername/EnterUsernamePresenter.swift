import Foundation
import FirebaseAuth
import FirebaseFirestore

final class EnterUsernamePresenter {
    private weak var view: EnterUsernameViewController?
    private var router: EnterUsernameRouter
    
    init(view: EnterUsernameViewController?, router: EnterUsernameRouter) {
        self.view = view
        self.router = router
    }
    
    // MARK: - View To Presenter
    func backButtonTapped() {
        router.navigateToWellcome()
    }
    

    func continueButtonTapped(name: String) {
        let db = Firestore.firestore()
        let clothesRef = db.collection("user").document(Auth.auth().currentUser!.uid)
        clothesRef.updateData(["name": name]) { error in
            if let error = error {
                print("Error updating document: \(error)")
            } else {
                print("Document successfully updated")
            }
        }
        
        UserDataManager.shared.updateUserProfileWithImage(image: ProfileConstants.Images.avatar!)
        router.navigateToWardrobe()
    }
    
}
