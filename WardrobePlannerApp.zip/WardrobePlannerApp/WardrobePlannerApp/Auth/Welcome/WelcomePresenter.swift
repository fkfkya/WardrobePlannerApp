import Foundation

final class WelcomePresenter {
    private weak var view: WelcomeViewController?
    private var router: WelcomeRouter
    
    init(view: WelcomeViewController?, router: WelcomeRouter) {
        self.view = view
        self.router = router
    }
    
    func registerButtonTapped() {
        router.navigateToRegistration()
    }
    
    func loginButtonTapped() {
        router.navigateToLogin()
    }
}
