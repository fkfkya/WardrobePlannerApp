import UIKit
import FirebaseAuth

class SceneDelegate: UIResponder, UIWindowSceneDelegate {

    var window: UIWindow?

    func scene(_ scene: UIScene, willConnectTo session: UISceneSession, options connectionOptions: UIScene.ConnectionOptions) {
        
        guard let windowScene = (scene as? UIWindowScene) else { return }
        let window = UIWindow(windowScene: windowScene)
        

        var initialViewController = UIViewController()
        let currentUser = Auth.auth().currentUser
        if currentUser != nil {
            if let username = currentUser?.displayName {
            } else {
                print("Имя пользователя не установлено ")
            }
            initialViewController = TabBarController()
        } else {
            initialViewController = WelcomeBuilder.build()
        }
        
        window.rootViewController = UINavigationController(rootViewController: initialViewController)
        self.window = window
        window.makeKeyAndVisible()
    }

    func sceneDidDisconnect(_ scene: UIScene) {
    
    }

    func sceneDidBecomeActive(_ scene: UIScene) {

    }

    func sceneWillResignActive(_ scene: UIScene) {
    }

    func sceneWillEnterForeground(_ scene: UIScene) {
    }

    func sceneDidEnterBackground(_ scene: UIScene) {
    }


}

