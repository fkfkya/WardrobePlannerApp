import Foundation
import FirebaseAuth
import FirebaseStorage
import UIKit

final class UserDataManager {
    
    public static let shared = UserDataManager()
    private let currentUser = Auth.auth().currentUser
    
    private init() {}
    
    // MARK: - SET methods
    func setEmail(newEmail: String, password: String) {

        let credential = EmailAuthProvider.credential(withEmail: self.getUserEmail(), password: password)

        currentUser?.reauthenticate(with: credential) { authResult, error in
            if let error = error {
                print("Ошибка повторной аутентификации: \(error.localizedDescription)")
            } else {
                self.currentUser?.sendEmailVerification(beforeUpdatingEmail: newEmail) { error in
                    if let error = error {
                        print("Ошибка отправки подтверждения на новый адрес и обновления адреса электронной почты: \(error.localizedDescription)")
                    } else {
                        print("Ошибка обновления адреса электронной почты")
                    }
                }
            }
        }
    }
    
    func updateUserProfileWithImage(image: UIImage) {
        if let user = Auth.auth().currentUser {
            let storageRef = Storage.storage().reference().child("avatars/\(user.uid).jpg")

            if let imageData = image.jpegData(compressionQuality: 0.5) {
                storageRef.putData(imageData, metadata: nil) { (metadata, error) in
                    if let error = error {
                        print("Ошибка загрузки изображения в хранилище Firebase: \(error.localizedDescription)")
                        return
                    }

                    storageRef.downloadURL { (url, error) in
                        if let error = error {
                            print("Ошибка получения URL загруженного изображения: \(error.localizedDescription)")
                            return
                        }

                        // Обновляем URL аватарки пользователя в базе данных Firebase
                        let changeRequest = user.createProfileChangeRequest()
                        changeRequest.photoURL = url
                        changeRequest.commitChanges { error in
                            if let error = error {
                                print("Ошибка обновления URL аватарки пользователя: \(error.localizedDescription)")
                                return
                            }
                            print("URL аватарки пользователя успешно обновлен")
                        }
                    }
                }
            } else {
                print("Ошибка: Невозможно преобразовать изображение в данные формата JPEG")
            }
        } else {
            print("Ошибка: Пользователь не авторизован в Firebase")
        }
    }


    func setUserName(_ newName: String) {
        let changeRequest = currentUser?.createProfileChangeRequest()
        changeRequest?.displayName = newName
        print(newName)
        changeRequest?.commitChanges { (error) in
            if let error = error {
                print("Ошибка при обновлении профиля: \(error.localizedDescription)")
            } else {
                if let updatedUsername = Auth.auth().currentUser?.displayName {
                    print("Новое имя пользователя: \(updatedUsername)")
                }
            }
        }
    }
    
    // MARK: - GET methods
    func getUser() -> User {
        return currentUser!
    }
    
    func getUserEmail() -> String {
        return (Auth.auth().currentUser?.email)!
    }
    
    func getUserName() -> String {
        return (Auth.auth().currentUser?.displayName) ?? "valentin"
    }

    func getUserAvatar(completion: @escaping (UIImage?) -> Void) {
        if let user = Auth.auth().currentUser {
            let storageRef = Storage.storage().reference().child("avatars/\(user.uid).jpg")

            storageRef.getData(maxSize: 10 * 1024 * 1024) { (data, error) in
                if let error = error {
                    print("Ошибка загрузки изображения из хранилища Firebase: \(error.localizedDescription)")
                    completion(nil)
                    return
                }
                
                guard let imageData = data else {
                    print("Ошибка: Данные изображения не получены")
                    completion(nil)
                    return
                }
                
                if let image = UIImage(data: imageData) {
                    completion(image)
                } else {
                    print("Ошибка: Невозможно создать изображение из полученных данных")
                    completion(nil)
                }
            }
        } else {
            print("Ошибка: Пользователь не авторизован в Firebase")
            completion(nil)
        }
    }


}
