import Foundation
import FirebaseAuth
import FirebaseFirestore
import FirebaseStorage
import UIKit

final class ClothesDataManager {
    
    public static let shared = ClothesDataManager()
    private let currentUser = Auth.auth().currentUser
    private let currentUid = Auth.auth().currentUser?.uid
    
    private init() {}
    
    // MARK: - SET methods
    
    // MARK: - Clothes
    public func addClothes(clothes: Clothes) {
        guard let imageData = clothes.image?.jpegData(compressionQuality: 0.9) else {
            print("Не удалось получить данные изображения")
            return
        }
        
        let storageRef = Storage.storage().reference().child("users_pictures").child(currentUid!).child("clothes").child("\(clothes.date!).jpg")
                    
        storageRef.putData(imageData, metadata: nil) { (metadata, error) in
            if let error = error {
                print("Ошибка при загрузке фотографии в Firebase Storage: \(error.localizedDescription)")
                return
            } else {
                print("Фотография успешно загружена в Firebase Storage")
            }
        }
        
    
        Firestore.firestore().collection("user").document(currentUid!).collection("clothes").document("\(clothes.date ?? "")").setData(clothes.getClothesData()){ error in
                if let error = error {
                    print("Ошибка при обновлении данных: \(error.localizedDescription)")
                } else { print("Поле успешно добавлено к документу") }
            }
             
    }
    
    public func setWish(clothes: Clothes) {
            let db = Firestore.firestore()
        let clothesRef = db.collection("user").document(currentUid!).collection("clothes").document("\(clothes.date ?? "")")
            
        clothesRef.updateData(["wish": clothes.wish]) { error in
                if let error = error {
                    print("Error updating document: \(error)")
                } else {
                    print("Document successfully updated")
                }
            }
    }
    
    public func deleteClothes(clothes: Clothes) {
        Firestore.firestore().collection("user").document(currentUid!).collection("clothes").document("\(clothes.date ?? "")").delete(){ error in
                if let error = error {
                    print("Ошибка при удалении данных: \(error.localizedDescription)")
                } else { print("Поле успешно удалено из документа") }
        }
    }
    
    public func addNewCategory(category: String) {
        let db = Firestore.firestore()
        let categoryRef = db.collection("user").document(currentUid!).collection("categories").document(category)
        
        categoryRef.setData(["name": category]) { error in
            if let error = error {
                print("Error updating document: \(error)")
            } else {
                print("Document successfully updated")
            }
        }
    }
    
    // MARK: - Outfit
    public func addOutfit(outfit: Outfit) {
        let storageRef = Storage.storage().reference().child("users_pictures").child(currentUid!).child("outfits").child(outfit.name)
        
        var idx: Int = 1
        for image in outfit.clothes{
            guard let imageData = image.jpegData(compressionQuality: 0.9) else {
                print("Не удалось получить данные изображения")
                return
            }
            
            storageRef.child("\(idx).jpg").putData(imageData, metadata: nil) { (metadata, error) in
                if let error = error {
                    print("Ошибка при загрузке фотографии в Firebase Storage: \(error.localizedDescription)")
                    return
                } else {
                    print("Фотография успешно загружена в Firebase Storage")
                }
            }
            idx += 1
        }
        
        
        Firestore.firestore().collection("user").document(currentUid!).collection("outfit").document(outfit.name).setData(outfit.getOutfitData()){ error in
            if let error = error {
                print("Ошибка при обновлении данных: \(error.localizedDescription)")
            } else { print("Поле успешно добавлено к документу") }
        }
        
    }
    
    public func setWish(outfit: Outfit) {
        let db = Firestore.firestore()
        let clothesRef = db.collection("user").document(currentUid!).collection("outfit").document(outfit.name)
            
        clothesRef.updateData(["wish": outfit.wish]) { error in
                if let error = error {
                    print("Error updating document: \(error)")
                } else {
                    print("Document successfully updated")
                }
            }
    }
    
    public func deleteOutfit(outfit: Outfit) {
        Firestore.firestore().collection("user").document(currentUid!).collection("outfit").document(outfit.name).delete(){ error in
                if let error = error {
                    print("Ошибка при удалении данных: \(error.localizedDescription)")
                } else { print("Поле успешно удалено из документа") }
        }
    }
    
    // MARK: - Get methods

}
