import UIKit

final class CategoryCell: UICollectionViewCell {
    static let reuseId = "category"
    
    private let wrapView: UIView = UIView()
    
    private let nameLabel: UILabel = UILabel()
    
    private let deleteButton: UIButton = UIButton(type: .system)
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        configureUI()
    }
    
    private func configureUI() {
        configureWrap()
        configureNameLabel()
    }
    
    @available(*, unavailable)
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func configure(with category: String) {
        nameLabel.text = category
    }
    
    private func configureWrap() {
        addSubview(wrapView)
        wrapView.backgroundColor = UIColor.cellBackground
        wrapView.layer.cornerRadius = 20
        wrapView.layer.shadowColor = UIColor.gray.cgColor
        wrapView.layer.shadowOpacity = 25
        wrapView.layer.shadowOffset = CGSize.init(width: 0, height: 0)
        wrapView.pinHorizontal(to: self, 5)
        wrapView.pinVertical(to: self, 6)
    }
 
    private func configureNameLabel() {
        wrapView.addSubview(nameLabel)
        
        nameLabel.lineBreakMode = .byTruncatingTail
        
        nameLabel.font = UIFont.boldSystemFont(ofSize: 18)
        nameLabel.numberOfLines = 0
        nameLabel.pinCenterY(to: wrapView.centerYAnchor)
        nameLabel.numberOfLines = 1
        nameLabel.setWidth(175)
        nameLabel.textAlignment = .center
        nameLabel.pinCenterX(to: wrapView.centerXAnchor)
    }
    
}
