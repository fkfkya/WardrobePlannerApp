import UIKit

final class OutfitCell: UICollectionViewCell {
    static let reuseId = "outfit"
    
    private let wrapView: UIView = UIView()
    
    private let nameLabel: UILabel = UILabel()
    
    private let image: UIImageView = UIImageView()

    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        configureUI()
    }
    
    private func configureUI() {
        configureWrap()
        configureImage()
        configureNameLabel()
    }
    
    @available(*, unavailable)
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func configure(with outfit: Outfit) {
        nameLabel.text = outfit.name
        
        image.image = outfit.clothes.first
    }
    
    private func configureWrap() {
        addSubview(wrapView)
        wrapView.backgroundColor = UIColor.cellBackground
        wrapView.layer.cornerRadius = 20
        wrapView.layer.shadowColor = UIColor.gray.cgColor
        wrapView.layer.shadowOpacity = 25
        wrapView.layer.shadowOffset = CGSize.init(width: 0, height: 0)
        wrapView.pinHorizontal(to: self, 5)
        wrapView.pinVertical(to: self, 6)
    }
    
    private func configureImage() {
        wrapView.addSubview(image)
        image.setWidth(130)
        image.setHeight(130)
        image.layer.cornerRadius = 15
        image.clipsToBounds = true
        image.pinCenterX(to: wrapView.centerXAnchor)
        image.pinTop(to: wrapView.topAnchor, 10)
    }
    
    private func configureNameLabel() {
        wrapView.addSubview(nameLabel)
        
        nameLabel.lineBreakMode = .byTruncatingTail
        
        nameLabel.font = UIFont.boldSystemFont(ofSize: 18)
        nameLabel.numberOfLines = 0
        nameLabel.pinBottom(to: wrapView.bottomAnchor, 9)
        nameLabel.numberOfLines = 1
        nameLabel.setWidth(175)
        nameLabel.textAlignment = .center
        nameLabel.pinCenterX(to: wrapView.centerXAnchor)
    }
    
}
