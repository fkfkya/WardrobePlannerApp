import UIKit
import FirebaseStorage

struct Outfit {
    init(clothes: [UIImage] = [], name: String, description: String? = nil, wish: Bool = false) {
        self.clothes = clothes
        self.name = name
        self.description = description
        self.wish = wish
    }
    
    var clothes: [UIImage]
    var name: String
    var description: String?
    var wish: Bool
    
    public func getOutfitData() -> [String: Any]{
        let data: [String: Any] = [
                "name": name,
                "description": description ?? "",
                "wish": wish
            ]
        return data
    }
    
    public mutating func addImage(dataImage: Data ){
        if let image = UIImage(data: dataImage) {
            self.clothes.append(image)
        }
    }
    
    public func getCountOfImages() -> Int {
        return self.clothes.count
    }

}
