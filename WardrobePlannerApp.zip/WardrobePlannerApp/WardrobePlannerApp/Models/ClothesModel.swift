import UIKit

struct Clothes {
    init(color: UIColor, size: String, category: String? = nil, name: String,
         cost: Double, description: String? = nil, image: UIImage? = AddingClothesConstans.Images.thing, date: String?, wish: Bool = false) {
        self.color = color
        self.size = size
        self.category = category
        self.name = name
        self.cost = cost
        self.description = description
        self.image = image
        self.date = date
        self.wish = wish
    }
    var name: String
    var color: UIColor
    var size: String
    var category: String?
    var cost: Double
    var description: String?
    var image: UIImage?
    var date: String?
    var wish: Bool
    
    public func getClothesData() -> [String: Any]{
        let data: [String: Any] = [
                "category": category ?? "",
                "name": name,
                "cost": cost,
                "size": size,
                "color": color.toHexString(),
                "description": description ?? "",
                "date": date ?? "",
                "wish": wish
            ]
        return data
    }
}
