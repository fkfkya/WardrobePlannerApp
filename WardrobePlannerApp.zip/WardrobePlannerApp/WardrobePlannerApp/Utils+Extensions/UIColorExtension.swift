import UIKit

extension UIColor {
    convenience init(hexString: String) {
        let hex = hexString.trimmingCharacters(in: CharacterSet.alphanumerics.inverted)
        var int = UInt64()
        Scanner(string: hex).scanHexInt64(&int)
        let a, r, g, b: UInt64
        switch hex.count {
        case 3: // RGB (12-bit)
            (a, r, g, b) = (255, (int >> 8) * 17, (int >> 4 & 0xF) * 17, (int & 0xF) * 17)
        case 6: // RGB (24-bit)
            (a, r, g, b) = (255, int >> 16, int >> 8 & 0xFF, int & 0xFF)
        case 8: // ARGB (32-bit)
            (a, r, g, b) = (int >> 24, int >> 16 & 0xFF, int >> 8 & 0xFF, int & 0xFF)
        default:
            (a, r, g, b) = (255, 0, 0, 0)
        }
        self.init(red: CGFloat(r) / 255, green: CGFloat(g) / 255, blue: CGFloat(b) / 255, alpha: CGFloat(a) / 255)
    }
    
    func toHexString() -> String {
            guard let components = cgColor.components, components.count >= 3 else {
                return "FFFFFF"
            }

            let red = Int(components[0] * 255.0)
            let green = Int(components[1] * 255.0)
            let blue = Int(components[2] * 255.0)

            let hexString = String(format: "%02X%02X%02X", red, green, blue)

            return hexString
    }
    static let systemBackground = UIColor { traitCollection -> UIColor in
            return ((traitCollection.userInterfaceStyle == .dark ? UIColor(named: "tink") : UIColor(named: "whiteBack")) ?? .white)
        }
        
        static let label = UIColor { traitCollection -> UIColor in
            return traitCollection.userInterfaceStyle == .dark ? .white : .black
        }
        
        static let textLabel = UIColor { traitCollection -> UIColor in
            return traitCollection.userInterfaceStyle == .dark ? .lightGray : .black
        }
        
        static var textFieldBorder: CGColor {
            if #available(iOS 13.0, *) {
                return UIColor { traitCollection -> UIColor in
                    return traitCollection.userInterfaceStyle == .dark ? UIColor.white : UIColor.black
                }.cgColor
            } else {
                return UIColor.white.cgColor
            }
        }
        
        static let cellBackground = UIColor { traitCollection -> UIColor in
            return traitCollection.userInterfaceStyle == .dark ? .systemGray6 : .white
        }
        
        static let shadowColor = UIColor { traitCollection -> UIColor in
            return traitCollection.userInterfaceStyle == .dark ? .systemPink : .systemPink
        }.cgColor
}
