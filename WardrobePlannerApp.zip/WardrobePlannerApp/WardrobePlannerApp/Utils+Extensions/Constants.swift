import UIKit

struct ColorsConstants {
    static let background = UIColor(hexString: "#AECFE4")
    static let agreeColor = UIColor(hexString: "#00A923")
    static let editColor = UIColor(hexString: "#0099FF")
}

struct ChangeConstants {
    enum indentation {
        static let buttonsY: CGFloat = 12
        static let buttonLeft: CGFloat = 40
        static let buttonRight: CGFloat = 40
    }
}

// MARK: - ProfileView
struct ProfileConstants {
    enum Names {
        static let emailLabel = "Current email"
        static let nameLabel = "Username"
        static let photoLabel = "Profile's photo"
        static let passLabel = "Password"
        
        static let stars = "********"
        
        static let photoButton = "Change"
    }
    
    enum Sizes {
        static let slideMain = UIScreen.main.bounds.height / 8
        
        static let photoLabel: CGFloat = 25
        static let otherLabel: CGFloat = 18
    }
    
    enum Images {
        static let avatar = UIImage(named: "avatar_icon")
    }
}

// MARK: - CalendarView
struct CalendarConstants {
    static let frame: CGRect = CGRect(x: 0, y: 0, width: 320, height: 300)
    static let calendarSlideY: CGFloat = UIScreen.main.bounds.height / 8
    static let heightAnchor: CGFloat = 275
    static let layerSize: CGFloat = 3.0
    static let layerColor = UIColor(named: "customPurple")
    static let LayerRadius: CGFloat = 20
    static let daysBorderRadius: CGFloat = 0.35
    
    
    static let mainLabelText = "Planner"
    static let mainLabelTextSize: CGFloat = 24
    static let mainLabelTop: CGFloat = 70
    static let mainLabelColor = UIColor(named: "customPurple")
}

// MARK: - AddingClothesView
struct AddingClothesConstans {
    
    enum PhotoPicker {
        static let camera = UIImage(named: "camera_icon")
        static let gallery = UIImage(named: "gallery_icon")

        static let iconWidth: CGFloat = 51.2
        static let iconHeight: CGFloat = 38
        static let iconSlide: CGFloat = -30
        
        static let mainRadius: CGFloat = 20
    }
    
    enum Images {
        static let thing = UIImage(named: "thing_icon")
        static let hanger = UIImage(named: "hanger_icon")
    }
    
    enum Names{
        static let mainLabel = "Adding to wardrobe"
        static let addThingLabel = "Items"
        static let addLookLabel = "Looks"
        static let restrictionsLabel = "No more than 10 MB, 1920x1080px"
        
        static let addThingButton = "Add item"
        static let createLookButton = "Create look"
        
        static let addPhoto = "Add photo"
        static let chooseFromGalleryButton = "Select from gallery"
        static let takePhotoButton = "Take a photo"
    }
    
    enum Colors {
        static let restrictions = UIColor(hexString: "#7F0017")
        static let buttonLayerColor = UIColor(hexString: "#006FDF")
        static let buttonBackground = UIColor(hexString: "#006FDF")
        static let colorTitle =  UIColor(hexString: "#FFF59C")
        static let backgroundButtons = UIColor(hexString: "#A3E2F6")
    }
    
    enum Sizes {
        static let imageY: CGFloat = 20
        static let imageX: CGFloat = -50
        static let imageHeight: CGFloat = 100
        
        static let imageHangerHeight: CGFloat = 90
        
        // MAIN BUTTONS
        static let buttonTitleOfSize: CGFloat = 20
        static let buttonLayerWidth = WardrobeViewConstants.ShowClothingButton.layerBorderWidth
        static let buttonLayerRadius: CGFloat = 15
        static let buttonPinBottom: CGFloat = -50
        static let buttonHeight: CGFloat = 45
        static let buttonWidth: CGFloat = 150
        
        //OPT BUTTONS
        static let optButtonTitleOfSize: CGFloat = 16
        static let optButtonHeight: CGFloat = 45
        static let optButtonWidth: CGFloat = 220
        static let optButtonsRadius: CGFloat = 21
        static let optButtonSlideY: CGFloat = 25
        static let optOptSlideY: CGFloat = 20
        
        static let restrOf: CGFloat = 11
        static let restrSlideY: CGFloat = 10
        static let mainLabelOf: CGFloat = 30
        static let mainLabelTop: CGFloat = UIScreen.main.bounds.height / 8
        
        static let addThingLabelOf: CGFloat = 18
        static let addThingLabel: CGFloat = UIScreen.main.bounds.height / 8
        
        static let addLookLabelOf: CGFloat = 18
        static let addLookLabel: CGFloat = UIScreen.main.bounds.height / 6
        
        static let indentationX: CGFloat = 30
        static let slideX: CGFloat = 40
    }
    
}

struct AuthConstants {
    // MARK: - WelcomeViewController
    static let appNameTop: CGFloat = UIScreen.main.bounds.height / 3
    
    static let appNameOfSize: CGFloat = 35
    
    static let registerButtonBottom: CGFloat = 30
    static let registerCornerRadius: CGFloat = 30
    static let registerBorderWidth:CGFloat = 4
    
    static let loginButtonHeight: CGFloat = 25
    static let loginButtonBottom: CGFloat = UIScreen.main.bounds.height / 8
    
    // MARK: - EnterEmailViewController
    static let labelTop: CGFloat = UIScreen.main.bounds.height / 3
    static let signInButtonBottom: CGFloat = loginButtonBottom + loginButtonHeight + registerButtonBottom
}


// MARK: - TabBar
struct TabBarConstants {
    enum Sizes {
        static let layerRadius: CGFloat = 10
        static let borderWidth: CGFloat = 1.4
    }
    
    enum Colors {
        static let bar = UIColor(hexString: "#989AA2")
        static let activeBar = UIColor(named: "activeBar")
        static let inactiveBar = UIColor(hexString: "#FFF59C")
        static let separator = UIColor(hexString: "#940093")
    }
    
    enum Images {
        static let wardrobe: UIImage = UIImage(systemName: "tshirt")!
        static let calendar: UIImage = UIImage(systemName: "calendar")!
        static let wishlist: UIImage = UIImage(systemName: "suit.heart.fill")!
        static let profile: UIImage = UIImage(systemName: "person")!
    }
    
    enum Names {
        static let wardrobe = "Wardrobe"
        static let calendar = "Calendar"
        static let wishlist = "Wishlist"
        static let profile = "Profile"
    }
}


// MARK: - WardrobeView
struct WardrobeViewConstants {
    
    enum AddClothesButton {
        static let name: String = "Add clothes"
        
        static let colorTitle = UIColor(hexString: "#FFF59C")
        static let layerBorderColor = UIColor(named: "customPurple")?.cgColor
        static let backroungColor = UIColor(hexString: "#006FDF")
        
        static let height: Double = 60
        static let width: Double = 255
        
        static let addButtonBottom: CGFloat = UIScreen.main.bounds.height / 2
        static let layerBorderWidth: CGFloat = 7.6
        static let layerCornerRadius: CGFloat = 22
        
    }
    enum ShowClothingButton {
        static let name: String = "My Wardrobe"
        
        static let colorTitle = UIColor(hexString: "#000000")
        static let layerBorderColor = UIColor(named: "customPurple")?.cgColor
        
        
        static let height: Double = 50
        static let width: Double = 240
        
        static let addButtonBottom: CGFloat = 15
        static let layerBorderWidth: CGFloat = 5
        static let layerCornerRadius: CGFloat = 24
    }
    
    enum ShowLooksButton{
        static let name: String = "My Looks"
        
        static let colorTitle = UIColor(hexString: "#000000")
        static let layerBorderColor = UIColor(named: "customPurple")?.cgColor
        
        static let height: Double = 50
        static let width: Double = 240
        
        static let addButtonBottom: CGFloat = 15
        static let layerBorderWidth: CGFloat = 5
        static let layerCornerRadius: CGFloat = 24
    }
    
    enum ShowCatigoriesButton {
        static let name: String = "Categories"
        
        static let colorTitle = UIColor(hexString: "#000000")
        static let layerBorderColor = UIColor(named: "customPurple")?.cgColor
        
        static let height: Double = 50
        static let width: Double = 240
        
        static let addButtonBottom: CGFloat = 15
        static let layerBorderWidth: CGFloat = 5
        static let layerCornerRadius: CGFloat = 24
    }

    
}
